from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes
import pandas as pd
import matplotlib.pyplot as plt
from io import BytesIO
import seaborn as sns
from datetime import datetime, timedelta
import asyncio
from typing import List, Dict

class AnalyticsTelegramBot:
    def __init__(self, database, resource_manager):
        self.db = database
        self.resource_manager = resource_manager
        self.bot = Application.builder().token(CONFIG['TELEGRAM_BOT_TOKEN']).build()
        
        # Регистрация обработчиков
        self.bot.add_handler(CommandHandler("start", self.start))
        self.bot.add_handler(CommandHandler("stats", self.stats))
        self.bot.add_handler(CommandHandler("contacts", self.contacts))
        self.bot.add_handler(CommandHandler("analytics", self.analytics))
        self.bot.add_handler(CommandHandler("mass_message", self.mass_message))
        self.bot.add_handler(CallbackQueryHandler(self.button_callback))
        
    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Начало работы с ботом"""
        keyboard = [
            [
                InlineKeyboardButton("📊 Статистика", callback_data="stats"),
                InlineKeyboardButton("👥 Контакты", callback_data="contacts")
            ],
            [
                InlineKeyboardButton("📈 Аналитика", callback_data="analytics"),
                InlineKeyboardButton("📫 Рассылка", callback_data="mass_message")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            "Панель управления системой поиска клиентов\n"
            "Выберите действие:",
            reply_markup=reply_markup
        )
    
    async def stats(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Подробная статистика"""
        stats = await self.get_system_stats()
        
        message = (
            "📊 *Системная статистика:*\n"
            f"CPU: {stats['cpu_usage']}%\n"
            f"RAM: {stats['memory_usage']}%\n"
            f"Активных задач: {stats['active_tasks']}\n\n"
            
            "🎯 *Статистика поиска:*\n"
            f"Всего найдено контактов: {stats['total_contacts']}\n"
            f"За последние 24 часа: {stats['contacts_24h']}\n"
            f"Конверсия: {stats['conversion_rate']}%\n\n"
            
            "👥 *Группы:*\n"
            f"Активных групп: {stats['active_groups']}\n"
            f"Мертвых групп: {len(self.resource_manager.dead_groups)}\n"
            f"Успешных проверок: {stats['successful_checks']}\n"
        )
        
        await update.message.reply_text(message, parse_mode='Markdown')
    
    async def contacts(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Управление контактами"""
        keyboard = [
            [
                InlineKeyboardButton("📥 Экспорт CSV", callback_data="export_csv"),
                InlineKeyboardButton("🔍 Поиск", callback_data="search_contacts")
            ],
            [
                InlineKeyboardButton("📊 По источникам", callback_data="contacts_by_source"),
                InlineKeyboardButton("📅 По дате", callback_data="contacts_by_date")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            "Управление контактами:\n"
            "Выберите действие:",
            reply_markup=reply_markup
        )
    
    async def analytics(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Расширенная аналитика"""
        # Создаем графики
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 12))
        
        # График находок по времени
        data = await self.get_contacts_timeline()
        sns.lineplot(data=data, x='date', y='contacts', ax=ax1)
        ax1.set_title('Динамика находок контактов')
        
        # График по источникам
        source_data = await self.get_contacts_by_source()
        sns.barplot(data=source_data, x='source', y='contacts', ax=ax2)
        ax2.set_title('Распределение по источникам')
        
        # Сохраняем график
        buf = BytesIO()
        plt.savefig(buf, format='png')
        buf.seek(0)
        
        await update.message.reply_photo(buf)
        
        # Отправляем текстовую аналитику
        analytics_text = await self.get_advanced_analytics()
        await update.message.reply_text(analytics_text, parse_mode='Markdown')
    
    async def mass_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Массовая рассылка"""
        if len(context.args) < 1:
            await update.message.reply_text(
                "Использование: /mass_message <текст сообщения>\n"
                "Дополнительные параметры:\n"
                "-f <фильтр по дате> (например: -f 7d для контактов за 7 дней)\n"
                "-s <источник> (например: -s vk для контактов из ВКонтакте)"
            )
            return
        
        # Парсим параметры
        message_text = " ".join(context.args)
        filters = self._parse_message_filters(context.args)
        
        # Получаем список контактов с учетом фильтров
        contacts = await self.get_filtered_contacts(filters)
        
        if not contacts:
            await update.message.reply_text("Нет контактов, подходящих под фильтры")
            return
        
        # Запускаем рассылку
        await self.start_mass_mailing(contacts, message_text, update.message.chat_id)
    
    async def start_mass_mailing(self, contacts: List[Dict], message: str, chat_id: int):
        """Запуск массовой рассылки"""
        total = len(contacts)
        success = 0
        failed = 0
        
        progress_message = await self.bot.send_message(
            chat_id,
            f"Начинаем рассылку для {total} контактов..."
        )
        
        for i, contact in enumerate(contacts, 1):
            try:
                # Здесь код отправки сообщения через соответствующий API
                success += 1
            except Exception as e:
                failed += 1
                logging.error(f"Error sending message to {contact}: {e}")
            
            # Обновляем прогресс каждые 10 контактов
            if i % 10 == 0:
                await progress_message.edit_text(
                    f"Прогресс: {i}/{total}\n"
                    f"Успешно: {success}\n"
                    f"Ошибок: {failed}"
                )
            
            await asyncio.sleep(0.1)  # Небольшая пауза между отправками
        
        await progress_message.edit_text(
            f"Рассылка завершена!\n"
            f"Всего контактов: {total}\n"
            f"Успешно отправлено: {success}\n"
            f"Ошибок: {failed}"
        )