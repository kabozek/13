from telethon import TelegramClient, events
from datetime import datetime, timedelta
import asyncio
import logging
import json
from typing import Dict, List

class TelegramMonitor:
    def __init__(self, config, ai_manager, database, logger):
        self.config = config
        self.ai_manager = ai_manager
        self.db = database
        self.logger = logger
        
        # Инициализация клиента Telegram
        self.client = TelegramClient(
            'leads_session',
            config['TELEGRAM']['API_ID'],
            config['TELEGRAM']['API_HASH']
        )
        
        self.stats = {
            'messages_processed': 0,
            'channels_monitored': 0,
            'leads_found': 0
        }
        
        self.monitored_channels = set()
        self.processed_messages = set()

    async def start(self):
        """Запуск мониторинга Telegram"""
        try:
            await self.client.start()
            self.logger.logger.info("Telegram client started successfully")
            
            # Регистрация обработчиков событий
            self.client.on(events.NewMessage)(self.handle_new_message)
            
            # Начальное обновление списка каналов
            await self.update_monitored_channels()
            
            # Бесконечный цикл для поддержания соединения
            while True:
                if not await self.client.is_user_authorized():
                    self.logger.logger.error("Telegram authorization lost")
                    await self.client.start()
                
                await self.update_stats()
                await asyncio.sleep(300)  # Проверка каждые 5 минут
                
        except Exception as e:
            self.logger.log_error(e, "Error in Telegram monitoring")
            raise

    async def update_monitored_channels(self):
        """Обновление списка отслеживаемых каналов"""
        try:
            search_terms = [
                'помощь', 'взаимопомощь', 'кредиты',
                'деньги', 'финансы', 'долги'
            ]
            
            new_channels = set()
            async for dialog in self.client.iter_dialogs():
                if dialog.is_channel:
                    for term in search_terms:
                        if term.lower() in dialog.title.lower():
                            new_channels.add(dialog.id)
                            break
            
            self.monitored_channels = new_channels
            self.stats['channels_monitored'] = len(self.monitored_channels)
            self.logger.logger.info(f"Updated monitored channels: {len(self.monitored_channels)}")
            
        except Exception as e:
            self.logger.log_error(e, "Error updating monitored channels")

    async def handle_new_message(self, event):
        """Обработка нового сообщения"""
        try:
            # Проверяем, не обрабатывали ли мы это сообщение ранее
            message_id = f"{event.chat_id}_{event.id}"
            if message_id in self.processed_messages:
                return
                
            self.processed_messages.add(message_id)
            self.stats['messages_processed'] += 1
            
            # Проверяем возраст сообщения
            message_date = event.date
            if datetime.now() - message_date > timedelta(days=self.config['MONITORING']['MAX_POST_AGE_DAYS']):
                return
            
            # Анализируем текст сообщения
            if event.message.text:
                analysis = await self.ai_manager.analyze_text(event.message.text)
                if analysis['relevant']:
                    await self.process_lead(event, analysis)
                    
        except Exception as e:
            self.logger.log_error(e, f"Error handling message {event.id}")

    async def process_lead(self, event, analysis: Dict):
        """Обработка потенциального лида"""
        try:
            # Получаем информацию о пользователе
            sender = await event.get_sender()
            
            lead_data = {
                'user_id': str(sender.id),
                'platform': 'telegram',
                'source_group': str(event.chat_id),
                'message_text': event.message.text,
                'contact_info': json.dumps({
                    'username': sender.username,
                    'first_name': sender.first_name,
                    'last_name': sender.last_name
                }),
                'score': analysis['score'],
                'category': analysis['category'],
                'status': 'new',
                'source_type': 'telegram_message',
                'source_url': f"t.me/c/{event.chat_id}/{event.id}",
                'created_at': datetime.now().isoformat()
            }
            
            # Сохраняем лид в базу
            await self.db.add_lead(lead_data)
            self.stats['leads_found'] += 1
            
            self.logger.logger.info(f"New lead found in Telegram: {sender.first_name or ''} {sender.last_name or ''}")
            
        except Exception as e:
            self.logger.log_error(e, f"Error processing lead from message {event.id}")

    async def update_stats(self):
        """Обновление статистики"""
        try:
            stats_data = {
                'telegram_monitor': {
                    'timestamp': datetime.utcnow().isoformat(),
                    'stats': self.stats,
                    'monitored_channels': len(self.monitored_channels),
                    'processed_messages': len(self.processed_messages)
                }
            }
            self.logger.log_stats(stats_data)
            
        except Exception as e:
            self.logger.log_error(e, "Error updating Telegram stats")

    async def stop(self):
        """Остановка мониторинга"""
        try:
            await self.client.disconnect()
            self.logger.logger.info("Telegram client stopped successfully")
        except Exception as e:
            self.logger.log_error(e, "Error stopping Telegram client")