from dataclasses import dataclass
from datetime import datetime
import asyncio
from typing import List, Dict, Set
import logging

@dataclass
class GroupPerformanceMetrics:
    target_audience_score: float  # 0-1
    engagement_rate: float  # 0-1
    conversion_rate: float  # 0-1
    response_time: float  # среднее время ответа в минутах
    active_hours: Set[int]  # часы активности (0-23)
    successful_leads: int
    total_messages: int

class SmartGroupSelector:
    def __init__(self, city: str, region: str):
        self.city = city
        self.region = region
        self.group_metrics = {}
        self.group_categories = {
            'financial_help': [
                'помощь', 'взаимопомощь', 'финансы', 'деньги',
                'поддержка', 'благотворительность'
            ],
            'job_search': [
                'работа', 'вакансии', 'подработка', 'карьера',
                'ищу работу', 'резюме', 'hr'
            ],
            'local_communities': [
                'подслушано', 'район', 'город', 'жители',
                'соседи', 'новости города'
            ],
            'marketplace': [
                'барахолка', 'объявления', 'продажа', 'куплю продам',
                'авито', 'доска объявлений'
            ],
            'emergency_help': [
                'срочно', 'помогите', 'нужна помощь', 'sos',
                'взаимопомощь', 'поддержка'
            ]
        }
        
        # Паттерны финансовых проблем
        self.financial_patterns = [
            {
                'keywords': ['задержка', 'зарплата', 'выплата'],
                'context': ['нет', 'когда', 'будет', 'задерживают'],
                'weight': 0.8
            },
            {
                'keywords': ['долг', 'кредит', 'займ'],
                'context': ['нужно погасить', 'как закрыть', 'проблемы'],
                'weight': 0.9
            },
            {
                'keywords': ['работа', 'увольнение', 'сокращение'],
                'context': ['потерял', 'ищу', 'нет', 'срочно'],
                'weight': 0.7
            },
            {
                'keywords': ['продам', 'продаю', 'отдам'],
                'context': ['срочно', 'нужны деньги', 'торг'],
                'weight': 0.6
            }
        ]
        
    async def analyze_target_audience(self, group_id: str, posts: List[Dict]) -> float:
        """Анализ целевой аудитории группы"""
        try:
            relevant_posts = 0
            total_analyzed = 0
            
            for post in posts:
                if total_analyzed >= 100:  # Анализируем последние 100 постов
                    break
                    
                text = post.get('text', '').lower()
                
                # Проверяем паттерны финансовых проблем
                pattern_matches = 0
                pattern_weights = 0
                
                for pattern in self.financial_patterns:
                    keyword_match = any(kw in text for kw in pattern['keywords'])
                    context_match = any(ctx in text for ctx in pattern['context'])
                    
                    if keyword_match and context_match:
                        pattern_matches += 1
                        pattern_weights += pattern['weight']
                
                if pattern_matches > 0:
                    relevance_score = pattern_weights / pattern_matches
                    if relevance_score > 0.5:
                        relevant_posts += 1
                        
                total_analyzed += 1
            
            return relevant_posts / total_analyzed if total_analyzed > 0 else 0
            
        except Exception as e:
            logging.error(f"Error analyzing target audience for group {group_id}: {e}")
            return 0
    
    async def calculate_engagement_rate(self, group_id: str, posts: List[Dict]) -> float:
        """Расчет уровня вовлеченности"""
        try:
            total_engagement = 0
            total_posts = len(posts)
            
            for post in posts:
                likes = post.get('likes', {}).get('count', 0)
                comments = post.get('comments', {}).get('count', 0)
                reposts = post.get('reposts', {}).get('count', 0)
                
                # Взвешенная оценка вовлеченности
                engagement = (likes * 1 + comments * 3 + reposts * 2)
                total_engagement += engagement
            
            return total_engagement / (total_posts * 100) if total_posts > 0 else 0
            
        except Exception as e:
            logging.error(f"Error calculating engagement rate for group {group_id}: {e}")
            return 0
    
    async def analyze_active_hours(self, posts: List[Dict]) -> Set[int]:
        """Анализ часов наибольшей активности"""
        try:
            hour_activity = {i: 0 for i in range(24)}
            
            for post in posts:
                post_time = datetime.fromtimestamp(post['date'])
                hour_activity[post_time.hour] += 1
                
                # Анализируем время комментариев
                if 'comments' in post and post['comments'].get('count', 0) > 0:
                    for comment in post['comments'].get('items', []):
                        comment_time = datetime.fromtimestamp(comment['date'])
                        hour_activity[comment_time.hour] += 1
            
            # Выбираем часы с активностью выше среднего
            avg_activity = sum(hour_activity.values()) / 24
            active_hours = {
                hour for hour, activity in hour_activity.items()
                if activity > avg_activity
            }
            
            return active_hours
            
        except Exception as e:
            logging.error(f"Error analyzing active hours: {e}")
            return set()
    
    async def update_group_metrics(self, group_id: str):
        """Обновление метрик группы"""
        try:
            posts = await self.get_group_posts(group_id)
            
            target_audience_score = await self.analyze_target_audience(group_id, posts)
            engagement_rate = await self.calculate_engagement_rate(group_id, posts)
            active_hours = await self.analyze_active_hours(posts)
            
            self.group_metrics[group_id] = GroupPerformanceMetrics(
                target_audience_score=target_audience_score,
                engagement_rate=engagement_rate,
                conversion_rate=self.calculate_conversion_rate(group_id),
                response_time=self.calculate_response_time(group_id),
                active_hours=active_hours,
                successful_leads=self.get_successful_leads(group_id),
                total_messages=len(posts)
            )
            
        except Exception as e:
            logging.error(f"Error updating metrics for group {group_id}: {e}")
    
    def get_optimal_posting_schedule(self, group_id: str) -> List[int]:
        """Определение оптимального времени для мониторинга"""
        if group_id not in self.group_metrics:
            return list(range(0, 24, 2))  # каждые 2 часа по умолчанию
            
        metrics = self.group_metrics[group_id]
        active_hours = sorted(metrics.active_hours)
        
        if not active_hours:
            return list(range(0, 24, 2))
            
        # Выбираем часы с наибольшей вероятностью успеха
        optimal_hours = []
        for hour in active_hours:
            if metrics.target_audience_score > 0.3:  # Если целевая аудитория активна
                optimal_hours.extend([hour-1, hour, hour+1])
        
        # Нормализуем часы
        optimal_hours = [h % 24 for h in optimal_hours]
        return sorted(set(optimal_hours))
    
    def calculate_group_priority(self, group_id: str) -> int:
        """Расчет приоритета группы для мониторинга"""
        if group_id not in self.group_metrics:
            return 3  # средний приоритет по умолчанию
            
        metrics = self.group_metrics[group_id]
        
        # Вычисляем общий скор
        score = (
            metrics.target_audience_score * 0.4 +
            metrics.engagement_rate * 0.3 +
            metrics.conversion_rate * 0.3
        )
        
        # Определяем приоритет
        if score > 0.8:
            return 1  # Высший приоритет
        elif score > 0.6:
            return 2
        elif score > 0.4:
            return 3
        elif score > 0.2:
            return 4
        else:
            return 5  # Низший приоритет
