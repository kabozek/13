import asyncio
import os
import sys
from datetime import datetime
from dotenv import load_dotenv
import logging

# Настройка логирования
logging.basicConfig(level=logging.INFO,
                   format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

async def check_environment():
    """Проверка переменных окружения"""
    # Принудительно перезагружаем .env
    load_dotenv(override=True)
    
    required_vars = {
        'VK_TOKEN': 'VK API токен',
        'TELEGRAM_BOT_TOKEN': 'Токен Telegram бота',
        'TELEGRAM_API_ID': 'Telegram API ID',
        'TELEGRAM_API_HASH': 'Telegram API Hash',
        'TELEGRAM_BOT_USERNAME': 'Имя пользователя бота',
        'ADMIN_USERNAME': 'Имя администратора'
    }
    
    missing = []
    present = []
    
    for var, description in required_vars.items():
        value = os.getenv(var)
        if not value or value.strip() == '':
            missing.append(f"{var} ({description})")
        else:
            present.append(f"{var} ({description})")
    
    if missing:
        logger.error("❌ Missing environment variables:")
        for var in missing:
            logger.error(f"  - {var}")
    
    if present:
        logger.info("✅ Present environment variables:")
        for var in present:
            logger.info(f"  - {var}")
    
    return len(missing) == 0

async def main():
    logger.info("🔍 Starting system check...")
    logger.info(f"📅 Current time (UTC): {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info(f"👤 Current user: {os.getenv('USER', 'unknown')}")
    
    # Проверяем .env файл
    if not os.path.exists('.env'):
        logger.error("❌ .env file does not exist!")
        return False
    
    # Проверяем переменные окружения
    env_ok = await check_environment()
    if not env_ok:
        logger.error("❌ Environment check failed!")
        return False
    
    logger.info("✅ All checks passed successfully!")
    return True

if __name__ == "__main__":
    try:
        if asyncio.run(main()):
            sys.exit(0)
        else:
            sys.exit(1)
    except KeyboardInterrupt:
        logger.info("\n👋 Check cancelled by user")
        sys.exit(0)
    except Exception as e:
        logger.error(f"\n❌ Critical error during check: {str(e)}")
        sys.exit(1)