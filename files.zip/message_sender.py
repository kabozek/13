from typing import Dict, List, Optional
from datetime import datetime
import asyncio

class MessageSender:
    def __init__(self, vk_monitor, telegram_monitor, database, logger):
        """
        Инициализация отправителя сообщений
        
        :param vk_monitor: Монитор VK
        :param telegram_monitor: Монитор Telegram
        :param database: База данных
        :param logger: Логгер
        """
        self.vk_monitor = vk_monitor
        self.telegram_monitor = telegram_monitor
        self.db = database
        self.logger = logger
        self.message_queue = asyncio.Queue()
        self.stats = {
            'messages_sent': 0,
            'errors': 0,
            'last_send_time': None
        }

    async def send_message(self, chat_id: str, message: str, platform: str = 'telegram') -> bool:
        """
        Отправка сообщения
        
        :param chat_id: ID чата
        :param message: Текст сообщения
        :param platform: Платформа (telegram/vk)
        :return: Успешность отправки
        """
        try:
            if platform == 'telegram':
                await self.telegram_monitor.send_message(chat_id, message)
            elif platform == 'vk':
                await self.vk_monitor.send_message(chat_id, message)
            
            self.stats['messages_sent'] += 1
            self.stats['last_send_time'] = datetime.utcnow().isoformat()
            
            # Логируем успешную отправку
            self.logger.logger.info(f"Message sent to {platform}:{chat_id}")
            return True
            
        except Exception as e:
            self.stats['errors'] += 1
            self.logger.log_error(e, f"Error sending message to {platform}:{chat_id}")
            return False

    async def queue_message(self, message_data: Dict) -> None:
        """
        Добавление сообщения в очередь
        
        :param message_data: Данные сообщения
        """
        await self.message_queue.put(message_data)

    async def process_queue(self) -> None:
        """Обработка очереди сообщений"""
        while True:
            try:
                # Получаем сообщение из очереди
                message_data = await self.message_queue.get()
                
                # Отправляем сообщение
                success = await self.send_message(
                    message_data['chat_id'],
                    message_data['message'],
                    message_data.get('platform', 'telegram')
                )
                
                # Если не удалось отправить, возвращаем в очередь
                if not success:
                    await asyncio.sleep(60)  # Ждем минуту перед повторной попыткой
                    await self.message_queue.put(message_data)
                
                # Небольшая задержка между сообщениями
                await asyncio.sleep(1)
                
            except Exception as e:
                self.logger.log_error(e, "Error processing message queue")
                await asyncio.sleep(5)

    async def broadcast_message(self, message: str, platform: str = 'all') -> Dict:
        """
        Массовая рассылка сообщения
        
        :param message: Текст сообщения
        :param platform: Платформа (all/telegram/vk)
        :return: Статистика рассылки
        """
        stats = {
            'total': 0,
            'success': 0,
            'failed': 0
        }
        
        try:
            async with self.db.connect() as conn:
                # Получаем список активных чатов
                query = "SELECT platform, chat_id FROM chats WHERE is_active = 1"
                if platform != 'all':
                    query += f" AND platform = '{platform}'"
                
                cursor = await conn.execute(query)
                chats = await cursor.fetchall()
                
                stats['total'] = len(chats)
                
                # Отправляем сообщения
                for chat_platform, chat_id in chats:
                    if await self.send_message(chat_id, message, chat_platform):
                        stats['success'] += 1
                    else:
                        stats['failed'] += 1
                    
                    await asyncio.sleep(1)  # Задержка между отправками
                
        except Exception as e:
            self.logger.log_error(e, "Error in broadcast_message")
        
        return stats

    def get_stats(self) -> Dict:
        """
        Получение статистики отправки сообщений
        
        :return: Статистика
        """
        return {
            'messages_sent': self.stats['messages_sent'],
            'errors': self.stats['errors'],
            'last_send_time': self.stats['last_send_time'],
            'queue_size': self.message_queue.qsize()
        }