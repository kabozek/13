import os
import sys
import asyncio
import logging
import aiosqlite
import vk_api
from datetime import datetime
from dotenv import load_dotenv
from typing import Dict, List, Optional
import json

# Настройка цветного вывода
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

def print_status(message: str, status: bool):
    """Вывод статуса с цветом"""
    status_str = f"{Colors.GREEN}✓{Colors.ENDC}" if status else f"{Colors.FAIL}✗{Colors.ENDC}"
    print(f"{message}: {status_str}")

# Настройка логирования
def setup_logging():
    if not os.path.exists('logs'):
        os.makedirs('logs')
        
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler('logs/debug.log')
        ]
    )
    return logging.getLogger('Debug')

logger = setup_logging()

# Загружаем переменные окружения
load_dotenv()
print(f"\n{Colors.BOLD}Loading Environment Variables...{Colors.ENDC}")

async def check_environment():
    """Проверка переменных окружения"""
    env_vars = {
        'VK_TOKEN': os.getenv('VK_TOKEN'),
        'TELEGRAM_BOT_TOKEN': os.getenv('TELEGRAM_BOT_TOKEN'),
        'TELEGRAM_API_ID': os.getenv('TELEGRAM_API_ID'),
        'TELEGRAM_API_HASH': os.getenv('TELEGRAM_API_HASH'),
        'TELEGRAM_BOT_USERNAME': os.getenv('TELEGRAM_BOT_USERNAME'),
        'ADMIN_USERNAME': os.getenv('ADMIN_USERNAME')
    }
    
    print(f"\n{Colors.BOLD}Checking Environment Variables:{Colors.ENDC}")
    all_ok = True
    for key, value in env_vars.items():
        status = bool(value)
        all_ok &= status
        print_status(f"  {key}", status)
    return all_ok

async def check_directories():
    """Проверка директорий"""
    directories = {
        'logs': ['leads_finder.log', 'errors.log', 'stats.log', 'debug.log'],
        'models': ['patterns.joblib'],
        'training_data': ['labeled_data.json']
    }
    
    print(f"\n{Colors.BOLD}Checking Directories and Files:{Colors.ENDC}")
    all_ok = True
    
    for dir_name, files in directories.items():
        if not os.path.exists(dir_name):
            os.makedirs(dir_name)
            print(f"  Created directory: {dir_name}")
        
        print(f"\n  {dir_name}:")
        for file_name in files:
            path = os.path.join(dir_name, file_name)
            if not os.path.exists(path):
                with open(path, 'w') as f:
                    if file_name.endswith('.json'):
                        json.dump([], f)
                    elif file_name.endswith('.joblib'):
                        f.write('')
            exists = os.path.exists(path)
            all_ok &= exists
            print_status(f"    {file_name}", exists)
    
    return all_ok

async def check_database():
    """Проверка базы данных"""
    print(f"\n{Colors.BOLD}Checking Database:{Colors.ENDC}")
    try:
        async with aiosqlite.connect('leads.db') as db:
            # Создаем необходимые таблицы
            tables = {
                'leads': '''
                    CREATE TABLE IF NOT EXISTS leads (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id TEXT NOT NULL,
                        platform TEXT NOT NULL,
                        source_group TEXT,
                        message_text TEXT,
                        contact_info TEXT,
                        score REAL,
                        category TEXT,
                        status TEXT,
                        created_at TEXT
                    )
                ''',
                'groups': '''
                    CREATE TABLE IF NOT EXISTS groups (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        platform TEXT NOT NULL,
                        group_id TEXT NOT NULL,
                        name TEXT,
                        members_count INTEGER,
                        activity_score REAL,
                        last_post_date TEXT,
                        is_active BOOLEAN
                    )
                ''',
                'stats': '''
                    CREATE TABLE IF NOT EXISTS stats (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        stat_type TEXT NOT NULL,
                        stat_data TEXT NOT NULL,
                        created_at TEXT
                    )
                '''
            }
            
            for table_name, query in tables.items():
                await db.execute(query)
                print_status(f"  Table '{table_name}'", True)
            
            await db.commit()
            return True
            
    except Exception as e:
        logger.error(f"Database check failed: {e}")
        print_status("  Database connection", False)
        return False

async def check_vk():
    """Проверка VK API"""
    print(f"\n{Colors.BOLD}Checking VK API:{Colors.ENDC}")
    try:
        token = os.getenv('VK_TOKEN')
        vk_session = vk_api.VkApi(token=token)
        vk = vk_session.get_api()
        
        # Проверяем доступ через тестовый запрос
        group_info = vk.groups.getById(group_ids=['1'])
        if group_info:
            print_status("  VK API Connection", True)
            print(f"  Test group name: {group_info[0]['name']}")
            return True
            
    except Exception as e:
        logger.error(f"VK API check failed: {e}")
        print_status("  VK API Connection", False)
        return False

async def check_telegram():
    """Проверка Telegram API"""
    print(f"\n{Colors.BOLD}Checking Telegram API:{Colors.ENDC}")
    try:
        from telegram.ext import Application
        
        token = os.getenv('TELEGRAM_BOT_TOKEN')
        app = Application.builder().token(token).build()
        print_status("  Telegram Bot Token", True)
        return True
        
    except Exception as e:
        logger.error(f"Telegram check failed: {e}")
        print_status("  Telegram Bot Token", False)
        return False

async def main():
    """Основная функция проверки"""
    print(f"\n{Colors.HEADER}Starting Debug Check{Colors.ENDC}")
    print(f"Time: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC")
    print(f"User: {os.getenv('USER', 'unknown')}")
    print("-" * 50)
    
    # Проверки
    env_ok = await check_environment()
    dir_ok = await check_directories()
    db_ok = await check_database()
    vk_ok = await check_vk()
    tg_ok = await check_telegram()
    
    # Итоговый статус
    print(f"\n{Colors.BOLD}Final Status:{Colors.ENDC}")
    checks = {
        "Environment": env_ok,
        "Directories": dir_ok,
        "Database": db_ok,
        "VK API": vk_ok,
        "Telegram": tg_ok
    }
    
    for check, status in checks.items():
        print_status(f"  {check}", status)
    
    if all(checks.values()):
        print(f"\n{Colors.GREEN}✨ All checks passed successfully!{Colors.ENDC}")
        return True
    else:
        print(f"\n{Colors.FAIL}❌ Some checks failed!{Colors.ENDC}")
        return False

if __name__ == "__main__":
    try:
        if asyncio.run(main()):
            print("\nSystem is ready to start!")
            sys.exit(0)
        else:
            print("\nPlease fix the issues before starting the bot!")
            sys.exit(1)
    except KeyboardInterrupt:
        print("\nDebug interrupted by user")
        sys.exit(0)
    except Exception as e:
        print(f"\n{Colors.FAIL}Critical error during debug: {e}{Colors.ENDC}")
        sys.exit(1)