import os
from dotenv import load_dotenv

# Загружаем переменные окружения
load_dotenv()

# Токены и ключи
VK_TOKEN = os.getenv('VK_TOKEN')
TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
TELEGRAM_API_ID = os.getenv('TELEGRAM_API_ID')
TELEGRAM_API_HASH = os.getenv('TELEGRAM_API_HASH')
TELEGRAM_BOT_USERNAME = os.getenv('TELEGRAM_BOT_USERNAME')
ADMIN_USERNAME = os.getenv('ADMIN_USERNAME')

# Настройки базы данных
DATABASE_FILE = 'leads.db'

# Настройки логирования
LOG_LEVEL = 'DEBUG'
LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
LOG_DIR = 'logs'
LOG_FILES = {
    'debug': 'debug.log',
    'error': 'errors.log',
    'leads': 'leads_finder.log',
    'stats': 'stats.log'
}