import os
from dotenv import load_dotenv

def check_env():
    """Проверка переменных окружения"""
    # Принудительно перезагружаем .env
    load_dotenv(override=True)
    
    # Проверяем каждую переменную
    variables = {
        'VK_TOKEN': os.getenv('VK_TOKEN'),
        'TELEGRAM_BOT_TOKEN': os.getenv('TELEGRAM_BOT_TOKEN'),
        'TELEGRAM_API_ID': os.getenv('TELEGRAM_API_ID'),
        'TELEGRAM_API_HASH': os.getenv('TELEGRAM_API_HASH'),
        'TELEGRAM_BOT_USERNAME': os.getenv('TELEGRAM_BOT_USERNAME'),
        'ADMIN_USERNAME': os.getenv('ADMIN_USERNAME')
    }
    
    print("\nEnvironment Variables Status:")
    print("-" * 50)
    
    all_present = True
    for var_name, value in variables.items():
        status = "✅ Present" if value else "❌ Missing"
        print(f"{var_name}: {status}")
        if not value:
            all_present = False
    
    print("-" * 50)
    if all_present:
        print("✨ All environment variables are present!")
    else:
        print("⚠️ Some environment variables are missing!")
    
    return all_present

if __name__ == "__main__":
    check_env()