import os
import shutil
from pathlib import Path

def cleanup_project():
    """Очистка и реорганизация проекта"""
    # Основные файлы и директории, которые нужно сохранить
    essential_files = {
        'main.py',
        'debug.py',
        'vk_api.py',
        'telegram_bot.py',
        'database.py',
        'config.py',
        'cleanup.py',
        '.env',
        'requirements.txt',
        'README.md',
        '.gitignore'
    }
    
    essential_dirs = {
        'logs',
        'models',
        'training_data',
        'utils'
    }
    
    # Получаем текущую директорию
    current_dir = Path('.')
    
    # Создаем бэкап директорию
    backup_dir = current_dir / 'backup'
    backup_dir.mkdir(exist_ok=True)
    
    # Перемещаем все неосновные файлы в backup
    for item in current_dir.iterdir():
        if item.name not in essential_files and \
           item.name not in essential_dirs and \
           item.name != 'backup' and \
           not item.name.startswith('.'):
            try:
                shutil.move(str(item), str(backup_dir / item.name))
                print(f"Moved {item.name} to backup/")
            except Exception as e:
                print(f"Error moving {item.name}: {e}")
    
    # Создаем отсутствующие директории
    for dir_name in essential_dirs:
        (current_dir / dir_name).mkdir(exist_ok=True)
        print(f"Created/verified directory: {dir_name}/")
    
    # Создаем базовые файлы в utils
    utils_dir = current_dir / 'utils'
    (utils_dir / '__init__.py').touch()
    
    print("\nProject cleanup completed!")
    print("\nCurrent project structure:")
    os.system('tree -a -I "backup|__pycache__|*.pyc|.git"')

if __name__ == "__main__":
    cleanup_project()