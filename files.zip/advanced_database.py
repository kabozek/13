from sqlalchemy import create_engine, Column, Integer, String, DateTime, Boolean, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
import json

Base = declarative_base()

class Contact(Base):
    __tablename__ = "contacts"
    
    id = Column(Integer, primary_key=True)
    source = Column(String)  # vk или telegram
    user_id = Column(String)
    username = Column(String, nullable=True)
    message = Column(String)
    post_link = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
    contacted = Column(Boolean, default=False)
    response_received = Column(Boolean, default=False)
    conversion_status = Column(String, default='new')  # new, contacted, converted, rejected
    contact_attempt_count = Column(Integer, default=0)
    last_contact_attempt = Column(DateTime, nullable=True)
    metadata = Column(String)  # JSON с дополнительной информацией
    
    def set_metadata(self, data: dict):
        self.metadata = json.dumps(data)
    
    def get_metadata(self) -> dict:
        return json.loads(self.metadata) if self.metadata else {}

class GroupStats(Base):
    __tablename__ = "group_stats"
    
    id = Column(Integer, primary_key=True)
    group_id = Column(String)
    name = Column(String)
    members_count = Column(Integer)
    activity_score = Column(Float)
    success_rate = Column(Float)
    last_check = Column(DateTime)
    total_contacts_found = Column(Integer, default=0)
    total_checks = Column(Integer, default=0)
    avg_check_interval = Column(Float)  # в секундах
    metadata = Column(String)  # JSON с дополнительной информацией

class Analytics(Base):
    __tablename__ = "analytics"
    
    id = Column(Integer, primary_key=True)
    date = Column(DateTime)
    total_contacts = Column(Integer)
    new_contacts = Column(Integer)
    converted_contacts = Column(Integer)
    active_groups = Column(Integer)
    dead_groups = Column(Integer)
    system_load = Column(Float)
    success_rate = Column(Float)
    metadata = Column(String)  # JSON с дополнительной информацией