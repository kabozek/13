import aiohttp
import asyncio
from datetime import datetime
from typing import Dict, List, Optional
import json
import os
from enum import Enum

class NotificationPriority(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class NotificationManager:
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.telegram_token = config['TELEGRAM']['BOT_TOKEN']
        self.admin_username = config['TELEGRAM']['ADMIN_USERNAME']
        self.notification_history = []
        self.notification_queue = asyncio.Queue()
        
    async def send_notification(self, 
                              message: str, 
                              priority: NotificationPriority,
                              data: Optional[Dict] = None):
        """Отправка уведомления"""
        try:
            notification = {
                'message': message,
                'priority': priority.value,
                'timestamp': datetime.utcnow().isoformat(),
                'data': data
            }
            
            # Добавляем в очередь
            await self.notification_queue.put(notification)
            
            # Сохраняем в историю
            self.notification_history.append(notification)
            
            # Очищаем старые уведомления (оставляем последние 1000)
            if len(self.notification_history) > 1000:
                self.notification_history = self.notification_history[-1000:]
            
            # Для критических уведомлений отправляем немедленно
            if priority == NotificationPriority.CRITICAL:
                await self._send_telegram_notification(notification)
                
        except Exception as e:
            self.logger.log_error(e, "Error sending notification")

    async def _send_telegram_notification(self, notification: Dict):
        """Отправка уведомления в Telegram"""
        try:
            message = (
                f"🔔 *{notification['priority'].upper()} Priority Notification*\n\n"
                f"Message: {notification['message']}\n"
                f"Time: {notification['timestamp']}\n"
            )
            
            if notification['data']:
                message += f"\nDetails:\n```json\n{json.dumps(notification['data'], indent=2)}\n```"
            
            async with aiohttp.ClientSession() as session:
                url = f"https://api.telegram.org/bot{self.telegram_token}/sendMessage"
                await session.post(url, json={
                    'chat_id': self.admin_username,
                    'text': message,
                    'parse_mode': 'Markdown'
                })
                
        except Exception as e:
            self.logger.log_error(e, "Error sending Telegram notification")

    async def process_notification_queue(self):
        """Обработка очереди уведомлений"""
        while True:
            try:
                # Группируем уведомления
                notifications = []
                try:
                    while True:
                        notification = self.notification_queue.get_nowait()
                        notifications.append(notification)
                except asyncio.QueueEmpty:
                    pass
                
                if notifications:
                    # Группируем по приоритету
                    grouped = {}
                    for notification in notifications:
                        priority = notification['priority']
                        if priority not in grouped:
                            grouped[priority] = []
                        grouped[priority].append(notification)
                    
                    # Отправляем сгруппированные уведомления
                    for priority, group in grouped.items():
                        if len(group) == 1:
                            await self._send_telegram_notification(group[0])
                        else:
                            summary = {
                                'priority': priority,
                                'timestamp': datetime.utcnow().isoformat(),
                                'message': f"Group of {len(group)} notifications",
                                'data': {
                                    'notifications': group
                                }
                            }
                            await self._send_telegram_notification(summary)
                
                await asyncio.sleep(60)  # Проверяем очередь каждую минуту
                
            except Exception as e:
                self.logger.log_error(e, "Error processing notification queue")
                await asyncio.sleep(60)

    def get_notification_stats(self) -> Dict:
        """Получение статистики уведомлений"""
        stats = {
            'total_notifications': len(self.notification_history),
            'by_priority': {},
            'last_24h': 0,
            'queue_size': self.notification_queue.qsize()
        }
        
        now = datetime.utcnow()
        for notification in self.notification_history:
            # Считаем по приоритетам
            priority = notification['priority']
            if priority not in stats['by_priority']:
                stats['by_priority'][priority] = 0
            stats['by_priority'][priority] += 1
            
            # Считаем за последние 24 часа
            notification_time = datetime.fromisoformat(notification['timestamp'])
            if (now - notification_time).total_seconds() < 86400:
                stats['last_24h'] += 1
        
        return stats