import os
import logging
from logging.handlers import RotatingFileHandler
from config import LOG_LEVEL, LOG_FORMAT, LOG_DIR, LOG_FILES

def setup_logger(name, log_file, level=LOG_LEVEL):
    """Настройка логгера"""
    if not os.path.exists(LOG_DIR):
        os.makedirs(LOG_DIR)
        
    formatter = logging.Formatter(LOG_FORMAT)
    
    # Файловый обработчик
    file_handler = RotatingFileHandler(
        os.path.join(LOG_DIR, log_file),
        maxBytes=10*1024*1024,  # 10MB
        backupCount=5
    )
    file_handler.setFormatter(formatter)
    
    # Консольный обработчик
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    
    # Настройка логгера
    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    return logger