# Система поиска клиентов в социальных сетях

## Требования
- Python 3.8+
- PostgreSQL 12+
- 2GB RAM минимум
- Стабильное интернет-соединение

## Установка

1. Создайте виртуальное окружение:
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate  # Windows