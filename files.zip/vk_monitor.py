import vk_api
import asyncio
from datetime import datetime, timedelta
import logging
from typing import List, Dict, Optional

class VKMonitor:
    def __init__(self, config, ai_manager, database, logger):
        self.config = config
        self.ai_manager = ai_manager
        self.db = database
        self.logger = logger
        self.vk = None
        self.is_running = False
        self.stats = {
            'messages_processed': 0,
            'leads_found': 0,
            'errors': 0,
            'last_update': None
        }

    def _init_vk(self) -> None:
        """Инициализация VK API"""
        try:
            self.vk = vk_api.VkApi(token=self.config['VK']['TOKEN'])
            self.logger.logger.info("VK API initialized successfully")
        except Exception as e:
            self.logger.log_error(e, "Error initializing VK API")
            raise

    async def start_monitoring(self) -> None:
        """Запуск мониторинга"""
        if not self.vk:
            self._init_vk()

        self.is_running = True
        self.logger.logger.info("VK monitoring started")

        while self.is_running:
            try:
                # Получаем активные группы
                groups = await self._get_active_groups()
                
                for group in groups:
                    # Получаем новые посты
                    posts = await self._get_group_posts(group['group_id'])
                    
                    # Анализируем посты
                    for post in posts:
                        await self._process_post(post, group)
                    
                    # Небольшая задержка между группами
                    await asyncio.sleep(1)
                
                # Обновляем статистику
                self.stats['last_update'] = datetime.utcnow().isoformat()
                
                # Ждем перед следующей проверкой
                await asyncio.sleep(self.config['MONITORING']['CHECK_INTERVAL'])
                
            except Exception as e:
                self.stats['errors'] += 1
                self.logger.log_error(e, "Error in VK monitoring loop")
                await asyncio.sleep(60)  # Ждем минуту перед повторной попыткой

    async def _get_active_groups(self) -> List[Dict]:
        """Получение активных групп"""
        try:
            async with self.db.connect() as conn:
                cursor = await conn.execute('''
                    SELECT * FROM groups 
                    WHERE platform = 'vk' AND is_active = 1
                ''')
                rows = await cursor.fetchall()
                return [dict(zip([col[0] for col in cursor.description], row)) for row in rows]
        except Exception as e:
            self.logger.log_error(e, "Error getting active groups")
            return []

    async def _get_group_posts(self, group_id: str, count: int = 100) -> List[Dict]:
        """Получение постов группы"""
        try:
            response = self.vk.method('wall.get', {
                'owner_id': -int(group_id),  # Минус для групп
                'count': count,
                'filter': 'all'
            })
            return response['items']
        except Exception as e:
            self.logger.log_error(e, f"Error getting posts for group {group_id}")
            return []

    async def _process_post(self, post: Dict, group: Dict) -> None:
        """Обработка поста"""
        try:
            # Проверяем возраст поста
            post_date = datetime.fromtimestamp(post['date'])
            if datetime.now() - post_date > timedelta(days=self.config['MONITORING']['MAX_POST_AGE_DAYS']):
                return

            # Анализируем текст
            text = post.get('text', '')
            if not text:
                return

            score = await self.ai_manager.analyze_text(text)
            
            if score > self.config['LOCAL_AI']['THRESHOLD']:
                # Создаем лид
                lead_data = {
                    'user_id': str(post['from_id']),
                    'platform': 'vk',
                    'source_group': group['group_id'],
                    'message_text': text,
                    'score': score,
                    'source_type': 'post',
                    'source_url': f"https://vk.com/wall{post['owner_id']}_{post['id']}"
                }
                
                await self.db.add_lead(lead_data)
                self.stats['leads_found'] += 1

            self.stats['messages_processed'] += 1
            
        except Exception as e:
            self.logger.log_error(e, f"Error processing post {post.get('id')}")

    def get_stats(self) -> Dict:
        """Получение статистики"""
        return self.stats

    async def stop(self) -> None:
        """Остановка мониторинга"""
        self.is_running = False
        self.logger.logger.info("VK monitoring stopped")