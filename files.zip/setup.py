import subprocess
import sys
import os
import logging

# Настройка логирования
logging.basicConfig(level=logging.INFO,
                   format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def install_requirements():
    """Установка необходимых пакетов"""
    try:
        logger.info("📦 Installing required packages...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        logger.info("✅ Packages installed successfully")
        return True
    except subprocess.CalledProcessError as e:
        logger.error(f"❌ Failed to install packages: {str(e)}")
        return False

def verify_installation():
    """Проверка установки пакетов"""
    required_packages = [
        'python-dotenv',
        'python-telegram-bot',
        'vk-api',
        'telethon',
        'transformers',
        'torch',
        'scikit-learn',
        'pandas',
        'numpy',
        'aiosqlite',
        'joblib',
        'psutil',
        'aiohttp'
    ]
    
    missing_packages = []
    for package in required_packages:
        try:
            __import__(package.replace('-', '_'))
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        logger.error(f"❌ Missing packages: {', '.join(missing_packages)}")
        return False
    
    logger.info("✅ All packages verified")
    return True

def main():
    logger.info("🚀 Starting setup...")
    
    # Устанавливаем пакеты
    if not install_requirements():
        return False
    
    # Проверяем установку
    if not verify_installation():
        return False
    
    logger.info("✨ Setup completed successfully!")
    logger.info("\nℹ️ Next steps:")
    logger.info("1. Run 'python init_project.py' to initialize the project")
    logger.info("2. Run 'python check_system.py' to verify setup")
    logger.info("3. Run 'python main.py' to start the application")
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)