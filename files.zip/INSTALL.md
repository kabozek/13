# Пошаговая инструкция по установке и запуску системы

## 1. Подготовка системы

### Установка необходимого ПО:
1. Python 3.8+ (https://www.python.org/downloads/)
2. PostgreSQL 12+ (https://www.postgresql.org/download/)
3. Git (https://git-scm.com/downloads)

## 2. Настройка проекта

1. Клонируйте репозиторий:
```bash
git clone [url_репозитория]
cd [папка_проекта]