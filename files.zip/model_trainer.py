import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from torch.utils.data import Dataset, DataLoader
import numpy as np
from sklearn.model_selection import train_test_split
import json
import os
from datetime import datetime

class LeadsDataset(Dataset):
    def __init__(self, texts, labels, tokenizer, max_length=512):
        self.encodings = tokenizer(texts, truncation=True, padding=True, max_length=max_length)
        self.labels = labels

    def __getitem__(self, idx):
        item = {key: torch.tensor(val[idx]) for key, val in self.encodings.items()}
        item['labels'] = torch.tensor(self.labels[idx])
        return item

    def __len__(self):
        return len(self.labels)

class ModelTrainer:
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Создаем директорию для обучающих данных
        os.makedirs('training_data', exist_ok=True)
        
        self.tokenizer = AutoTokenizer.from_pretrained('DeepPavlov/rubert-base-cased')
        self.model = AutoModelForSequenceClassification.from_pretrained(
            'DeepPavlov/rubert-base-cased',
            num_labels=2
        ).to(self.device)
        
    def prepare_training_data(self, data_file='training_data/labeled_data.json'):
        """Подготовка данных для обучения"""
        if not os.path.exists(data_file):
            return None, None
            
        with open(data_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            
        texts = [item['text'] for item in data]
        labels = [item['label'] for item in data]
        
        return train_test_split(texts, labels, test_size=0.2, random_state=42)
    
    async def train_model(self, epochs=3, batch_size=16):
        """Обучение модели"""
        try:
            # Подготовка данных
            train_texts, test_texts, train_labels, test_labels = self.prepare_training_data()
            if not train_texts:
                self.logger.logger.error("No training data found")
                return
            
            # Создание датасетов
            train_dataset = LeadsDataset(train_texts, train_labels, self.tokenizer)
            test_dataset = LeadsDataset(test_texts, test_labels, self.tokenizer)
            
            train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
            test_loader = DataLoader(test_dataset, batch_size=batch_size)
            
            # Оптимизатор
            optimizer = torch.optim.AdamW(self.model.parameters(), lr=2e-5)
            
            # Обучение
            self.model.train()
            for epoch in range(epochs):
                total_loss = 0
                for batch in train_loader:
                    optimizer.zero_grad()
                    
                    input_ids = batch['input_ids'].to(self.device)
                    attention_mask = batch['attention_mask'].to(self.device)
                    labels = batch['labels'].to(self.device)
                    
                    outputs = self.model(
                        input_ids=input_ids,
                        attention_mask=attention_mask,
                        labels=labels
                    )
                    
                    loss = outputs.loss
                    total_loss += loss.item()
                    
                    loss.backward()
                    optimizer.step()
                
                avg_loss = total_loss / len(train_loader)
                self.logger.logger.info(f"Epoch {epoch+1}/{epochs}, Average loss: {avg_loss:.4f}")
            
            # Сохранение модели
            save_path = f"models/trained_model_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            os.makedirs(save_path, exist_ok=True)
            self.model.save_pretrained(save_path)
            self.tokenizer.save_pretrained(save_path)
            
            # Оценка модели
            accuracy = await self.evaluate_model(test_loader)
            self.logger.logger.info(f"Model evaluation accuracy: {accuracy:.4f}")
            
        except Exception as e:
            self.logger.log_error(e, "Model training error")
    
    async def evaluate_model(self, test_loader):
        """Оценка точности модели"""
        self.model.eval()
        correct = 0
        total = 0
        
        with torch.no_grad():
            for batch in test_loader:
                input_ids = batch['input_ids'].to(self.device)
                attention_mask = batch['attention_mask'].to(self.device)
                labels = batch['labels'].to(self.device)
                
                outputs = self.model(input_ids=input_ids, attention_mask=attention_mask)
                predictions = torch.argmax(outputs.logits, dim=1)
                
                correct += (predictions == labels).sum().item()
                total += labels.size(0)
        
        return correct / total
    
    def add_training_example(self, text: str, is_relevant: bool):
        """Добавление нового примера для обучения"""
        try:
            data_file = 'training_data/labeled_data.json'
            
            # Загрузка существующих данных
            if os.path.exists(data_file):
                with open(data_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
            else:
                data = []
            
            # Добавление нового примера
            data.append({
                'text': text,
                'label': 1 if is_relevant else 0,
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            })
            
            # Сохранение обновленных данных
            with open(data_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            
            self.logger.logger.info(f"Added new training example: {text[:100]}...")
            
        except Exception as e:
            self.logger.log_error(e, "Error adding training example")