from typing import List, Dict
import asyncio
from datetime import datetime, timedelta

class SmartGroupFinder:
    def __init__(self, vk_monitor, database, logger):
        self.vk_monitor = vk_monitor
        self.db = database
        self.logger = logger
        self.productive_groups = set()
        self.last_update = None
        self.stats = {
            'groups_analyzed': 0,
            'productive_groups_found': 0,
            'average_members': 0,
            'update_count': 0
        }

    async def find_productive_groups(self) -> List[Dict]:
        """Поиск продуктивных групп"""
        try:
            self.stats['update_count'] += 1
            current_time = datetime.utcnow()
            
            # Обновляем не чаще раза в час
            if (self.last_update and 
                (current_time - self.last_update) < timedelta(hours=1)):
                return list(self.productive_groups)

            self.logger.logger.info("Starting productive groups search...")
            
            search_queries = [
                'помощь', 'взаимопомощь', 'деньги',
                'кредиты', 'займы', 'долги',
                'финансы', 'работа', 'подработка'
            ]
            
            new_productive_groups = set()
            total_members = 0
            groups_count = 0

            for query in search_queries:
                try:
                    groups = await self.vk_monitor.search_groups(query)
                    for group in groups:
                        if await self._is_group_productive(group):
                            new_productive_groups.add(group['id'])
                            total_members += group.get('members_count', 0)
                            groups_count += 1
                        
                        self.stats['groups_analyzed'] += 1
                        
                    await asyncio.sleep(0.5)  # Задержка между запросами
                    
                except Exception as e:
                    self.logger.log_error(e, f"Error searching groups for query: {query}")

            self.productive_groups = new_productive_groups
            self.last_update = current_time
            
            # Обновляем статистику
            self.stats['productive_groups_found'] = len(new_productive_groups)
            self.stats['average_members'] = total_members / groups_count if groups_count > 0 else 0
            
            self.logger.log_stats({
                'smart_group_finder': {
                    'timestamp': current_time.isoformat(),
                    'stats': self.stats
                }
            })
            
            return list(self.productive_groups)

        except Exception as e:
            self.logger.log_error(e, "Error in find_productive_groups")
            return list(self.productive_groups)

    async def _is_group_productive(self, group: Dict) -> bool:
        """Проверка продуктивности группы"""
        try:
            # Минимальное количество участников
            if group.get('members_count', 0) < 1000:
                return False

            # Получаем последние посты
            posts = await self.vk_monitor.get_group_posts(group['id'], count=10)
            
            if not posts:
                return False

            # Проверяем активность
            total_comments = 0
            total_likes = 0
            has_recent_posts = False

            for post in posts:
                post_date = datetime.fromtimestamp(post['date'])
                if datetime.now() - post_date < timedelta(days=7):
                    has_recent_posts = True
                
                total_comments += post.get('comments', {}).get('count', 0)
                total_likes += post.get('likes', {}).get('count', 0)

            if not has_recent_posts:
                return False

            # Считаем среднюю активность
            avg_engagement = (total_comments + total_likes) / len(posts)
            min_engagement = group.get('members_count', 0) * 0.001  # 0.1% от участников

            return avg_engagement >= min_engagement

        except Exception as e:
            self.logger.log_error(e, f"Error checking group productivity: {group.get('id')}")
            return False

    def get_stats(self) -> Dict:
        """Получение статистики поиска групп"""
        return {
            'last_update': self.last_update.isoformat() if self.last_update else None,
            'stats': self.stats
        }