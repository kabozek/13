import openai
from config import CONFIG
import asyncio
from typing import List, Dict
import logging
from datetime import datetime

class AIManager:
    def __init__(self):
        openai.api_key = CONFIG['OPENAI']['API_KEY']
        self.message_history = {}
        self.conversation_context = {}
        
    async def analyze_message(self, text: str, context: Dict = None) -> Dict:
        """Анализ сообщения с помощью ИИ"""
        try:
            response = await openai.ChatCompletion.acreate(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": CONFIG['AI']['SYSTEM_PROMPT']},
                    {"role": "user", "content": self._prepare_prompt(text, context)}
                ],
                temperature=0.7,
                max_tokens=500
            )
            
            analysis = response.choices[0].message.content
            return self._parse_ai_response(analysis)
            
        except Exception as e:
            logging.error(f"Error in AI analysis: {e}")
            return {"error": str(e)}
    
    async def generate_response(self, lead_info: Dict) -> str:
        """Генерация персонализированного ответа"""
        prompt = self._create_response_prompt(lead_info)
        
        try:
            response = await openai.ChatCompletion.acreate(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": CONFIG['AI']['RESPONSE_PROMPT']},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.8
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            logging.error(f"Error generating response: {e}")
            return None
    
    async def categorize_lead(self, text: str, user_history: List[str] = None) -> Dict:
        """Категоризация лида и оценка потенциала"""
        try:
            analysis = await self.analyze_message(text, {"history": user_history})
            
            return {
                "category": analysis.get("category", "unknown"),
                "potential_score": analysis.get("potential_score", 0),
                "interests": analysis.get("interests", []),
                "recommended_approach": analysis.get("recommended_approach", ""),
                "key_points": analysis.get("key_points", [])
            }
            
        except Exception as e:
            logging.error(f"Error in lead categorization: {e}")
            return {}