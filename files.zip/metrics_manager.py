import psutil
import os
import time
from datetime import datetime, timedelta
from typing import Dict, List
import numpy as np

class MetricsManager:
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.metrics_history = {}
        self.start_time = datetime.utcnow()
        
    async def collect_metrics(self) -> Dict:
        """Сбор всех метрик системы"""
        try:
            current_time = datetime.utcnow()
            
            metrics = {
                'timestamp': current_time.isoformat(),
                'system': await self._get_system_metrics(),
                'application': await self._get_application_metrics(),
                'performance': await self._get_performance_metrics(),
                'network': await self._get_network_metrics(),
                'storage': await self._get_storage_metrics()
            }
            
            # Сохраняем метрики в историю
            self._update_metrics_history(metrics)
            
            return metrics
            
        except Exception as e:
            self.logger.log_error(e, "Error collecting metrics")
            return {}

    async def _get_system_metrics(self) -> Dict:
        """Системные метрики"""
        cpu_times = psutil.cpu_times()
        memory = psutil.virtual_memory()
        
        return {
            'cpu': {
                'usage_percent': psutil.cpu_percent(interval=1),
                'per_cpu_percent': psutil.cpu_percent(interval=1, percpu=True),
                'times': {
                    'user': cpu_times.user,
                    'system': cpu_times.system,
                    'idle': cpu_times.idle
                },
                'load_average': os.getloadavg()
            },
            'memory': {
                'total': memory.total,
                'available': memory.available,
                'used': memory.used,
                'percent': memory.percent,
                'swap_used': psutil.swap_memory().used
            },
            'processes': {
                'total': len(psutil.pids()),
                'running': len([p for p in psutil.process_iter(['status']) 
                              if p.info['status'] == 'running'])
            }
        }

    async def _get_application_metrics(self) -> Dict:
        """Метрики приложения"""
        process = psutil.Process()
        
        return {
            'uptime': (datetime.utcnow() - self.start_time).total_seconds(),
            'process': {
                'cpu_percent': process.cpu_percent(),
                'memory_percent': process.memory_percent(),
                'threads': process.num_threads(),
                'open_files': len(process.open_files()),
                'connections': len(process.connections())
            },
            'file_stats': {
                'database_size': os.path.getsize('leads.db') if os.path.exists('leads.db') else 0,
                'log_files': sum(os.path.getsize(f'logs/{f}') 
                               for f in os.listdir('logs') if f.endswith('.log'))
            }
        }

    async def _get_performance_metrics(self) -> Dict:
        """Метрики производительности"""
        return {
            'disk_io': {
                'read_bytes': psutil.disk_io_counters().read_bytes,
                'write_bytes': psutil.disk_io_counters().write_bytes,
                'read_time': psutil.disk_io_counters().read_time,
                'write_time': psutil.disk_io_counters().write_time
            },
            'network_io': {
                'bytes_sent': psutil.net_io_counters().bytes_sent,
                'bytes_recv': psutil.net_io_counters().bytes_recv,
                'packets_sent': psutil.net_io_counters().packets_sent,
                'packets_recv': psutil.net_io_counters().packets_recv
            }
        }

    async def _get_network_metrics(self) -> Dict:
        """Сетевые метрики"""
        net_connections = psutil.net_connections()
        
        return {
            'connections': {
                'total': len(net_connections),
                'established': len([c for c in net_connections if c.status == 'ESTABLISHED']),
                'listening': len([c for c in net_connections if c.status == 'LISTEN']),
                'time_wait': len([c for c in net_connections if c.status == 'TIME_WAIT'])
            },
            'interfaces': {
                interface: addresses
                for interface, addresses in psutil.net_if_addrs().items()
            }
        }

    async def _get_storage_metrics(self) -> Dict:
        """Метрики хранилища"""
        disk_usage = psutil.disk_usage('/')
        
        return {
            'disk': {
                'total': disk_usage.total,
                'used': disk_usage.used,
                'free': disk_usage.free,
                'percent': disk_usage.percent
            },
            'io_stats': {
                'read_count': psutil.disk_io_counters().read_count,
                'write_count': psutil.disk_io_counters().write_count,
                'read_bytes': psutil.disk_io_counters().read_bytes,
                'write_bytes': psutil.disk_io_counters().write_bytes
            }
        }

    def _update_metrics_history(self, metrics: Dict):
        """Обновление истории метрик"""
        current_time = datetime.utcnow()
        
        # Удаляем старые метрики (старше 24 часов)
        cutoff_time = current_time - timedelta(hours=24)
        self.metrics_history = {
            timestamp: values
            for timestamp, values in self.metrics_history.items()
            if datetime.fromisoformat(timestamp) > cutoff_time
        }
        
        # Добавляем новые метрики
        self.metrics_history[metrics['timestamp']] = metrics

    def get_metrics_analysis(self) -> Dict:
        """Анализ метрик за последние 24 часа"""
        if not self.metrics_history:
            return {}
        
        cpu_usage = []
        memory_usage = []
        disk_usage = []
        
        for timestamp, metrics in self.metrics_history.items():
            cpu_usage.append(metrics['system']['cpu']['usage_percent'])
            memory_usage.append(metrics['system']['memory']['percent'])
            disk_usage.append(metrics['storage']['disk']['percent'])
        
        return {
            'cpu': {
                'mean': np.mean(cpu_usage),
                'max': np.max(cpu_usage),
                'min': np.min(cpu_usage),
                'std': np.std(cpu_usage)
            },
            'memory': {
                'mean': np.mean(memory_usage),
                'max': np.max(memory_usage),
                'min': np.min(memory_usage),
                'std': np.std(memory_usage)
            },
            'disk': {
                'mean': np.mean(disk_usage),
                'max': np.max(disk_usage),
                'min': np.min(disk_usage),
                'std': np.std(disk_usage)
            }
        }