from telegram.ext import Application, CommandHandler, MessageHandler, filters
from config import CONFIG
from database import SessionLocal, Lead
import asyncio

class LeadBot:
    def __init__(self):
        self.bot = Application.builder().token(CONFIG['TELEGRAM_BOT_TOKEN']).build()
        
    async def start(self, update, context):
        await update.message.reply_text(
            'Бот для мониторинга потенциальных клиентов запущен!'
        )
    
    async def get_stats(self, update, context):
        session = SessionLocal()
        total_leads = session.query(Lead).count()
        contacted_leads = session.query(Lead).filter(Lead.contacted == True).count()
        
        await update.message.reply_text(
            f"📊 Статистика:\n"
            f"Всего найдено лидов: {total_leads}\n"
            f"Обработано: {contacted_leads}\n"
            f"Ожидают обработки: {total_leads - contacted_leads}"
        )
        session.close()
    
    def run(self):
        self.bot.add_handler(CommandHandler("start", self.start))
        self.bot.add_handler(CommandHandler("stats", self.get_stats))
        self.bot.run_polling()

if __name__ == "__main__":
    bot = LeadBot()
    bot.run()