import vk_api
from config import CONFIG
import asyncio
import logging
from datetime import datetime
import time

class VKManager:
    def __init__(self):
        self.vk_session = vk_api.VkApi(token=CONFIG['VK']['TOKEN'])
        self.vk = self.vk_session.get_api()
        self.found_posts = set()
        
    async def search_groups(self, query: str, count: int = 100):
        """Поиск групп по запросу"""
        try:
            groups = self.vk.groups.search(
                q=query,
                count=count,
                sort=6,  # сортировка по размеру группы
                v=CONFIG['VK']['API_VERSION']
            )
            
            filtered_groups = [
                group for group in groups['items']
                if group['members_count'] >= CONFIG['FILTERS']['MIN_GROUP_MEMBERS']
            ]
            
            return filtered_groups
            
        except Exception as e:
            logging.error(f"Error searching groups: {e}")
            return []
    
    async def check_group_posts(self, group_id: int):
        """Проверка постов в группе"""
        try:
            posts = self.vk.wall.get(
                owner_id=-group_id,
                count=CONFIG['MONITORING']['MAX_POSTS_PER_CHECK'],
                v=CONFIG['VK']['API_VERSION']
            )
            
            relevant_posts = []
            for post in posts['items']:
                if await self._is_relevant_post(post):
                    relevant_posts.append(post)
            
            return relevant_posts
            
        except Exception as e:
            logging.error(f"Error checking group {group_id}: {e}")
            return []
    
    async def _is_relevant_post(self, post):
        """Проверка релевантности поста"""
        if not post.get('text'):
            return False
            
        text = post['text'].lower()
        
        # Проверка длины текста
        if not (CONFIG['FILTERS']['MIN_TEXT_LENGTH'] <= 
                len(text) <= 
                CONFIG['FILTERS']['MAX_TEXT_LENGTH']):
            return False
        
        # Проверка ключевых слов
        if not any(word in text for word in CONFIG['MONITORING']['KEYWORDS']):
            return False
        
        # Проверка на спам
        if any(word in text for word in CONFIG['FILTERS']['SPAM_WORDS']):
            return False
        
        # Проверка уникальности
        post_id = f"{post['owner_id']}_{post['id']}"
        if post_id in self.found_posts:
            return False
            
        self.found_posts.add(post_id)
        return True