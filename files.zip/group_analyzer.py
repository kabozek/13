from vk_api import VkApi
from telethon import TelegramClient
import asyncio
from datetime import datetime, timedelta
import logging
from typing import List, Dict
from dataclasses import dataclass
from collections import Counter

@dataclass
class GroupMetrics:
    group_id: str
    name: str
    members_count: int
    posts_per_day: float
    target_keywords_frequency: float
    financial_discussion_score: float
    activity_score: float
    relevance_score: float

class GroupAnalyzer:
    def __init__(self, vk_session: VkApi, telegram_client: TelegramClient):
        self.vk = vk_session.get_api()
        self.tg = telegram_client
        
        # Ключевые индикаторы для оценки групп
        self.financial_keywords = [
            'деньги', 'займ', 'кредит', 'зарплата', 'работа',
            'подработка', 'доход', 'банк', 'финансы', 'долг',
            'выплата', 'срочно нужны', 'где взять', 'помощь',
            'задержка зп', 'авито', 'продам', 'куплю'
        ]
        
        # Индикаторы финансовых проблем
        self.problem_indicators = [
            'нет денег', 'задержали зарплату', 'уволили',
            'сократили', 'нужна помощь', 'ищу работу',
            'срочно продам', 'возьму в долг', 'где найти работу'
        ]
        
        # Категории групп для поиска
        self.group_categories = [
            'работа', 'подработка', 'объявления', 'барахолка',
            'продажа', 'авито', 'подслушано', 'помощь',
            'город', 'район', 'недвижимость', 'аренда'
        ]

    async def find_relevant_groups(self, city: str = None, region: str = None) -> List[GroupMetrics]:
        """Поиск релевантных групп на основе местоположения и категорий"""
        relevant_groups = []
        
        # Формируем поисковые запросы для каждой категории
        search_queries = []
        for category in self.group_categories:
            if city:
                search_queries.append(f"{category} {city}")
            if region:
                search_queries.append(f"{category} {region}")
            search_queries.append(category)

        for query in search_queries:
            try:
                # Поиск групп ВКонтакте
                groups = self.vk.groups.search(
                    q=query,
                    type='group',
                    sort=6,  # Сортировка по количеству участников
                    count=100
                )

                for group in groups['items']:
                    # Получаем детальную информацию о группе
                    group_info = self.vk.groups.getById(
                        group_id=group['id'],
                        fields=['members_count', 'activity', 'description']
                    )[0]
                    
                    # Анализируем активность группы
                    activity_metrics = await self.analyze_group_activity(group['id'])
                    
                    # Создаем метрики группы
                    metrics = GroupMetrics(
                        group_id=str(group['id']),
                        name=group_info['name'],
                        members_count=group_info.get('members_count', 0),
                        posts_per_day=activity_metrics['posts_per_day'],
                        target_keywords_frequency=activity_metrics['keyword_frequency'],
                        financial_discussion_score=activity_metrics['financial_score'],
                        activity_score=activity_metrics['activity_score'],
                        relevance_score=self.calculate_relevance_score(activity_metrics)
                    )
                    
                    relevant_groups.append(metrics)

            except Exception as e:
                logging.error(f"Error searching groups with query '{query}': {e}")

        # Сортируем группы по релевантности
        relevant_groups.sort(key=lambda x: x.relevance_score, reverse=True)
        
        # Возвращаем топ-100 самых релевантных групп
        return relevant_groups[:100]

    async def analyze_group_activity(self, group_id: str) -> Dict:
        """Анализ активности группы за последние 7 дней"""
        try:
            posts = self.vk.wall.get(owner_id=f"-{group_id}", count=100)
            current_time = datetime.now()
            
            # Анализируем посты за последнюю неделю
            recent_posts = [
                post for post in posts['items']
                if current_time - datetime.fromtimestamp(post['date']) <= timedelta(days=7)
            ]
            
            if not recent_posts:
                return {
                    'posts_per_day': 0,
                    'keyword_frequency': 0,
                    'financial_score': 0,
                    'activity_score': 0
                }

            # Подсчет частоты постов
            posts_per_day = len(recent_posts) / 7
            
            # Анализ текстов постов и комментариев
            all_text = []
            keyword_matches = Counter()
            
            for post in recent_posts:
                if 'text' in post:
                    all_text.append(post['text'].lower())
                    
                    # Подсчет ключевых слов
                    for keyword in self.financial_keywords:
                        if keyword in post['text'].lower():
                            keyword_matches[keyword] += 1
                    
                    # Анализ комментариев
                    try:
                        comments = self.vk.wall.getComments(
                            owner_id=f"-{group_id}",
                            post_id=post['id'],
                            count=100
                        )
                        
                        for comment in comments['items']:
                            if 'text' in comment:
                                all_text.append(comment['text'].lower())
                                for keyword in self.financial_keywords:
                                    if keyword in comment['text'].lower():
                                        keyword_matches[keyword] += 1
                    
                    except Exception as e:
                        logging.warning(f"Error getting comments for post {post['id']}: {e}")

            # Расчет метрик
            total_words = sum(len(text.split()) for text in all_text)
            keyword_frequency = sum(keyword_matches.values()) / max(total_words, 1)
            
            # Оценка финансовых обсуждений
            financial_score = sum(
                text.count(indicator) 
                for text in all_text 
                for indicator in self.problem_indicators
            ) / max(len(recent_posts), 1)
            
            # Оценка активности
            activity_score = (
                posts_per_day * 0.3 +
                keyword_frequency * 0.4 +
                financial_score * 0.3
            )

            return {
                'posts_per_day': posts_per_day,
                'keyword_frequency': keyword_frequency,
                'financial_score': financial_score,
                'activity_score': activity_score
            }

        except Exception as e:
            logging.error(f"Error analyzing group {group_id}: {e}")
            return {
                'posts_per_day': 0,
                'keyword_frequency': 0,
                'financial_score': 0,
                'activity_score': 0
            }

    def calculate_relevance_score(self, metrics: Dict) -> float:
        """Расчет общего показателя релевантности группы"""
        weights = {
            'posts_per_day': 0.25,
            'keyword_frequency': 0.35,
            'financial_score': 0.25,
            'activity_score': 0.15
        }
        
        return sum(metrics[key] * weights[key] for key in weights)
