from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackQueryHandler
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
import logging
import json
from datetime import datetime
import matplotlib.pyplot as plt
import io
import asyncio

class LeadsFinderBot:
    def __init__(self, config