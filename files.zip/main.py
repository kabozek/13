import asyncio
from datetime import datetime
import sys
from config import *
from utils.logger import setup_logger
from vk_api import VKAPIHandler
from telegram.ext import Application, CommandHandler, MessageHandler, filters

# Настройка логирования
logger = setup_logger('Main', LOG_FILES['debug'])

class LeadsFinderBot:
    def __init__(self):
        self.vk = VKAPIHandler(VK_TOKEN)
        self.telegram = None
        self.running = False
        
    async def start_command(self, update, context):
        """Обработчик команды /start"""
        user = update.effective_user
        await update.message.reply_text(
            f'Привет, {user.first_name}! 👋\n'
            f'Я бот для поиска лидов в VK и Telegram.\n'
            f'Используйте /help для получения списка команд.'
        )
        
    async def help_command(self, update, context):
        """Обработчик команды /help"""
        help_text = (
            "Доступные команды:\n"
            "/start - Начать работу с ботом\n"
            "/help - Показать это сообщение\n"
            "/status - Показать статус бота\n"
            "/search <keyword> - Поиск по ключевому слову"
        )
        await update.message.reply_text(help_text)
        
    async def status_command(self, update, context):
        """Обработчик команды /status"""
        status = (
            f"🤖 Статус бота:\n"
            f"Время работы: {datetime.utcnow()}\n"
            f"VK API: Активен\n"
            f"Telegram API: Активен\n"
            f"База данных: Подключена"
        )
        await update.message.reply_text(status)
        
    async def run(self):
        """Запуск бота"""
        try:
            logger.info("Starting bot...")
            
            # Инициализация Telegram бота
            self.telegram = (
                Application.builder()
                .token(TELEGRAM_BOT_TOKEN)
                .build()
            )
            
            # Регистрация обработчиков команд
            self.telegram.add_handler(CommandHandler("start", self.start_command))
            self.telegram.add_handler(CommandHandler("help", self.help_command))
            self.telegram.add_handler(CommandHandler("status", self.status_command))
            
            # Запуск бота
            self.running = True
            await self.telegram.run_polling()
            
        except Exception as e:
            logger.error(f"Error starting bot: {e}")
            raise
            
    async def stop(self):
        """Остановка бота"""
        if self.running:
            logger.info("Stopping bot...")
            self.running = False
            if self.telegram:
                await self.telegram.stop()

async def main():
    """Основная функция"""
    try:
        logger.info("Initializing bot...")
        bot = LeadsFinderBot()
        await bot.run()
    except KeyboardInterrupt:
        logger.info("Received shutdown signal")
        if bot:
            await bot.stop()
    except Exception as e:
        logger.error(f"Critical error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nBot stopped by user")
        sys.exit(0)
    except Exception as e:
        print(f"\nCritical error: {e}")
        sys.exit(1)