import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional

class AnalyticsManager:
    def __init__(self, database, logger):
        self.db = database
        self.logger = logger
        self.stats = {
            'leads': {},
            'groups': {},
            'performance': {}
        }
        self.last_update = None

    async def update(self) -> None:
        """Обновление аналитики"""
        try:
            current_time = datetime.utcnow()
            
            # Обновляем статистику не чаще раза в час
            if (self.last_update and 
                (current_time - self.last_update) < timedelta(hours=1)):
                return

            # Собираем статистику
            await self._update_leads_stats()
            await self._update_groups_stats()
            await self._update_performance_stats()
            
            # Сохраняем статистику
            await self._save_stats()
            
            self.last_update = current_time
            
        except Exception as e:
            self.logger.log_error(e, "Error updating analytics")

    async def _update_leads_stats(self) -> None:
        """Обновление статистики по лидам"""
        try:
            async with self.db.connect() as conn:
                # Получаем статистику по лидам
                cursor = await conn.execute('''
                    SELECT 
                        status,
                        COUNT(*) as count,
                        AVG(score) as avg_score
                    FROM leads
                    GROUP BY status
                ''')
                rows = await cursor.fetchall()
                
                self.stats['leads'] = {
                    'total': sum(row[1] for row in rows),
                    'by_status': {row[0]: row[1] for row in rows},
                    'avg_score': sum(row[2] for row in rows) / len(rows) if rows else 0
                }
                
        except Exception as e:
            self.logger.log_error(e, "Error updating leads stats")

    async def _update_groups_stats(self) -> None:
        """Обновление статистики по группам"""
        try:
            async with self.db.connect() as conn:
                cursor = await conn.execute('''
                    SELECT 
                        platform,
                        COUNT(*) as count,
                        AVG(members_count) as avg_members,
                        AVG(activity_score) as avg_activity
                    FROM groups
                    WHERE is_active = 1
                    GROUP BY platform
                ''')
                rows = await cursor.fetchall()
                
                self.stats['groups'] = {
                    'total_active': sum(row[1] for row in rows),
                    'by_platform': {row[0]: {
                        'count': row[1],
                        'avg_members': row[2],
                        'avg_activity': row[3]
                    } for row in rows}
                }
                
        except Exception as e:
            self.logger.log_error(e, "Error updating groups stats")

    async def _update_performance_stats(self) -> None:
        """Обновление статистики производительности"""
        try:
            current_time = datetime.utcnow()
            day_ago = current_time - timedelta(days=1)
            
            async with self.db.connect() as conn:
                cursor = await conn.execute('''
                    SELECT 
                        COUNT(*) as processed,
                        AVG(CASE WHEN score > 0.7 THEN 1 ELSE 0 END) as accuracy
                    FROM leads
                    WHERE created_at > ?
                ''', (day_ago.isoformat(),))
                row = await cursor.fetchone()
                
                self.stats['performance'] = {
                    'daily_processed': row[0],
                    'accuracy': row[1] if row[1] is not None else 0,
                    'uptime': (current_time - self.last_update).total_seconds() if self.last_update else 0
                }
                
        except Exception as e:
            self.logger.log_error(e, "Error updating performance stats")

    async def _save_stats(self) -> None:
        """Сохранение статистики в базу данных"""
        try:
            async with self.db.connect() as conn:
                await conn.execute('''
                    INSERT INTO stats (stat_type, stat_data, created_at)
                    VALUES (?, ?, ?)
                ''', ('daily_stats', json.dumps(self.stats), datetime.utcnow().isoformat()))
                await conn.commit()
                
            self.logger.log_stats(self.stats)
            
        except Exception as e:
            self.logger.log_error(e, "Error saving stats")

    def get_current_stats(self) -> Dict:
        """Получение текущей статистики"""
        return {
            'timestamp': datetime.utcnow().isoformat(),
            'stats': self.stats,
            'last_update': self.last_update.isoformat() if self.last_update else None
        }

    async def get_historical_stats(self, days: int = 7) -> List[Dict]:
        """Получение исторической статистики"""
        try:
            start_date = datetime.utcnow() - timedelta(days=days)
            
            async with self.db.connect() as conn:
                cursor = await conn.execute('''
                    SELECT stat_data, created_at
                    FROM stats
                    WHERE created_at > ?
                    ORDER BY created_at DESC
                ''', (start_date.isoformat(),))
                rows = await cursor.fetchall()
                
                return [{'data': json.loads(row[0]), 'timestamp': row[1]} for row in rows]
                
        except Exception as e:
            self.logger.log_error(e, "Error getting historical stats")
            return []