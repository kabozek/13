from dataclasses import dataclass
from datetime import datetime, timedelta
import psutil
import asyncio
import logging
from typing import Dict, Set

@dataclass
class ResourceUsage:
    cpu_percent: float
    memory_percent: float
    network_usage: float
    requests_per_minute: int
    last_update: datetime

class ResourceManager:
    def __init__(self):
        self.resource_usage = ResourceUsage(0, 0, 0, 0, datetime.now())
        self.active_tasks = set()
        self.dead_groups = set()
        self.group_request_counters: Dict[str, int] = {}
        self.last_successful_checks: Dict[str, datetime] = {}
        
        # Лимиты ресурсов
        self.MAX_CPU_PERCENT = 80
        self.MAX_MEMORY_PERCENT = 85
        self.MAX_REQUESTS_PER_MINUTE = 2500  # Общий лимит запросов в минуту
        
    async def monitor_resources(self):
        while True:
            try:
                cpu_percent = psutil.cpu_percent()
                memory_percent = psutil.Process().memory_percent()
                
                self.resource_usage = ResourceUsage(
                    cpu_percent=cpu_percent,
                    memory_percent=memory_percent,
                    network_usage=self._get_network_usage(),
                    requests_per_minute=sum(self.group_request_counters.values()),
                    last_update=datetime.now()
                )
                
                # Очистка счетчиков запросов
                if datetime.now().second == 0:  # В начале каждой минуты
                    self.group_request_counters.clear()
                
                # Проверка и очистка мертвых групп
                await self._cleanup_dead_groups()
                
            except Exception as e:
                logging.error(f"Error monitoring resources: {e}")
            
            await asyncio.sleep(5)  # Проверка каждые 5 секунд
    
    def can_process_group(self, group_id: str) -> bool:
        """Проверка возможности обработки группы"""
        # Проверка ресурсов системы
        if (self.resource_usage.cpu_percent > self.MAX_CPU_PERCENT or
            self.resource_usage.memory_percent > self.MAX_MEMORY_PERCENT or
            self.resource_usage.requests_per_minute >= self.MAX_REQUESTS_PER_MINUTE):
            return False
        
        # Проверка, не является ли группа мертвой
        if group_id in self.dead_groups:
            return False
        
        # Проверка лимита запросов для группы
        group_requests = self.group_request_counters.get(group_id, 0)
        if group_requests > 30:  # Максимум 30 запросов в минуту на группу
            return False
            
        return True
    
    async def _cleanup_dead_groups(self):
        """Очистка неактивных групп"""
        current_time = datetime.now()
        
        for group_id, last_check in self.last_successful_checks.items():
            # Если группа не была активна более 7 дней
            if current_time - last_check > timedelta(days=7):
                self.dead_groups.add(group_id)
                logging.info(f"Group {group_id} marked as dead due to inactivity")
    
    def register_request(self, group_id: str):
        """Регистрация запроса к группе"""
        self.group_request_counters[group_id] = (
            self.group_request_counters.get(group_id, 0) + 1
        )
    
    def register_successful_check(self, group_id: str):
        """Регистрация успешной проверки группы"""
        self.last_successful_checks[group_id] = datetime.now()
        if group_id in self.dead_groups:
            self.dead_groups.remove(group_id)