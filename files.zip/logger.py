import logging
import os
from datetime import datetime
from logging.handlers import RotatingFileHandler
import json

class CustomLogger:
    def __init__(self):
        # Создаем директорию для логов
        os.makedirs('logs', exist_ok=True)
        
        # Настройка основного логгера
        self.logger = logging.getLogger('LeadsFinder')
        self.logger.setLevel(logging.DEBUG)
        
        # Форматтер для логов
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
        # Хендлер для консоли
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(formatter)
        
        # Хендлер для файла с общими логами
        file_handler = RotatingFileHandler(
            'logs/leads_finder.log',
            maxBytes=10*1024*1024,  # 10MB
            backupCount=5
        )
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(formatter)
        
        # Хендлер для ошибок
        error_handler = RotatingFileHandler(
            'logs/errors.log',
            maxBytes=10*1024*1024,
            backupCount=5
        )
        error_handler.setLevel(logging.ERROR)
        error_handler.setFormatter(formatter)
        
        # Хендлер для статистики
        self.stats_handler = RotatingFileHandler(
            'logs/stats.log',
            maxBytes=10*1024*1024,
            backupCount=5
        )
        
        # Добавляем хендлеры к логгеру
        self.logger.addHandler(console_handler)
        self.logger.addHandler(file_handler)
        self.logger.addHandler(error_handler)
        
    def log_lead(self, lead_data):
        """Логирование информации о найденном лиде"""
        self.logger.info(f"New lead found: {json.dumps(lead_data, ensure_ascii=False)}")
        
    def log_stats(self, stats_data):
        """Логирование статистики"""
        with open('logs/stats.log', 'a', encoding='utf-8') as f:
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            f.write(f"{timestamp} - {json.dumps(stats_data, ensure_ascii=False)}\n")
    
    def log_error(self, error, context=None):
        """Логирование ошибок с контекстом"""
        error_data = {
            'error': str(error),
            'context': context,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        self.logger.error(f"Error occurred: {json.dumps(error_data, ensure_ascii=False)}")