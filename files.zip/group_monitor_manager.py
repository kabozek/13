import asyncio
from typing import List, Dict
from datetime import datetime, timedelta
import logging
from dataclasses import dataclass
from collections import defaultdict

@dataclass
class MonitoringSchedule:
    group_id: str
    check_interval: int  # в секундах
    last_check: datetime
    priority: int  # 1-5, где 1 - высший приоритет
    success_rate: float  # 0-1, успешность нахождения целевых сообщений

class GroupMonitorManager:
    def __init__(self, analyzer, vk_monitor, telegram_monitor):
        self.analyzer = analyzer
        self.vk_monitor = vk_monitor
        self.telegram_monitor = telegram_monitor
        self.monitoring_schedules = {}
        self.group_stats = defaultdict(lambda: {
            'total_checks': 0,
            'successful_finds': 0,
            'last_success': None,
            'avg_interval': 300  # начальный интервал 5 минут
        })
        
        # Ограничения на проверки
        self.MIN_INTERVAL = 60  # минимальный интервал 1 минута
        self.MAX_INTERVAL = 3600  # максимальный интервал 1 час
        
    async def update_monitoring_schedule(self):
        """Обновление расписания мониторинга на основе эффективности"""
        while True:
            current_time = datetime.now()
            
            for group_id, schedule in self.monitoring_schedules.items():
                stats = self.group_stats[group_id]
                
                # Расчет успешности группы
                success_rate = stats['successful_finds'] / max(stats['total_checks'], 1)
                
                # Корректировка интервала проверки
                if success_rate > 0.3:  # Высокая эффективность
                    new_interval = max(
                        self.MIN_INTERVAL,
                        stats['avg_interval'] * 0.8  # Уменьшаем интервал
                    )
                elif success_rate < 0.1:  # Низкая эффективность
                    new_interval = min(
                        self.MAX_INTERVAL,
                        stats['avg_interval'] * 1.2  # Увеличиваем интервал
                    )
                else:
                    new_interval = stats['avg_interval']
                
                # Обновляем расписание
                self.monitoring_schedules[group_id].check_interval = int(new_interval)
                self.group_stats[group_id]['avg_interval'] = new_interval
            
            await asyncio.sleep(3600)  # Обновление раз в час

    async def monitor_groups(self):
        """Основной цикл мониторинга групп"""
        while True:
            current_time = datetime.now()
            tasks = []
            
            # Формируем список групп для проверки
            for group_id, schedule in self.monitoring_schedules.items():
                if current_time - schedule.last_check >= timedelta(seconds=schedule.check_interval):
                    # Добавляем задачу на проверку группы
                    if group_id.startswith('vk_'):
                        tasks.append(self.vk_monitor.monitor_group(group_id[3:]))
                    elif group_id.startswith('tg_'):
                        tasks.append(self.telegram_monitor.monitor_channel(group_id[3:]))
                    
                    # Обновляем время последней проверки
                    schedule.last_check = current_time
                    self.group_stats[group_id]['total_checks'] += 1

            # Выполняем проверки параллельно
            if tasks:
                results = await asyncio.gather(*tasks, return_exceptions=True)
                
                # Обрабатываем результаты
                for group_id, result in zip(self.monitoring_schedules.keys(), results):
                    if isinstance(result, Exception):
                        logging.error(f"Error monitoring group {group_id}: {result}")
                        continue
                        
                    if result:  # Если найдены новые сообщения
                        self.group_stats[group_id]['successful_finds'] += 1
                        self.group_stats[group_id]['last_success'] = current_time

            # Короткая пауза перед следующей итерацией
            await asyncio.sleep(1)

    def add_group(self, group_id: str, priority: int = 3):
        """Добавление новой группы для мониторинга"""
        self.monitoring_schedules[group_id] = MonitoringSchedule(
            group_id=group_id,
            check_interval=300,  # начальный интервал 5 минут
            last_check=datetime.now(),
            priority=priority,
            success_rate=0.0
        )
