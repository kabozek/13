from gpt4all import GPT4All
import json

class LeadAnalyzer:
    def __init__(self):
        # Инициализируем локальную модель GPT4All
        self.model = GPT4All("ggml-model-gpt4all-falcon-q4_0.bin")
        
        # Загружаем предварительно подготовленные сценарии
        self.scenarios = self._load_scenarios()
    
    def _load_scenarios(self):
        return {
            "financial_difficulty": [
                "потеря работы",
                "задержка зарплаты",
                "сокращение",
                "долги",
                "ремонт",
                "лечение",
                "срочные траты",
                "переезд",
                "учеба"
            ],
            "life_events": [
                "свадьба",
                "рождение ребенка",
                "переезд",
                "поступление в университет",
                "покупка техники"
            ],
            "emergency": [
                "сломалась машина",
                "заболел питомец",
                "срочный ремонт",
                "медицинские услуги"
            ]
        }
    
    def analyze_message(self, text):
        prompt = f"""
        Проанализируй следующее сообщение и определи, может ли автору понадобиться срочный займ:
        
        {text}
        
        Оцени по шкале от 0 до 100 вероятность того, что автор сообщения нуждается в срочных деньгах.
        Верни только число.
        """
        
        try:
            response = self.model.generate(prompt, max_tokens=10)
            score = float(response.strip())
            return score > 60  # Возвращаем True если вероятность выше 60%
        except:
            return False