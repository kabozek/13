import vk_api
from telethon import TelegramClient
from config import CONFIG
from database import SessionLocal, Lead
from datetime import datetime, timedelta
import asyncio
import logging

logger = logging.getLogger(__name__)

class VKMonitor:
    def __init__(self, analyzer):
        self.vk_session = vk_api.VkApi(token=CONFIG['VK_TOKEN'])
        self.vk = self.vk_session.get_api()
        self.analyzer = analyzer
        
    async def start_monitoring(self):
        while True:
            try:
                for group in CONFIG['VK_GROUPS']:
                    posts = self.vk.wall.get(domain=group, count=100)
                    for post in posts['items']:
                        # Проверяем возраст поста
                        post_date = datetime.fromtimestamp(post['date'])
                        if datetime.now() - post_date > timedelta(days=CONFIG['MAX_POST_AGE_DAYS']):
                            continue
                        
                        # Анализируем текст поста
                        if 'text' in post and self.analyzer.analyze_message(post['text']):
                            self._save_lead('vk', str(post['from_id']), post['text'], 
                                          f"vk.com/wall{post['owner_id']}_{post['id']}")
                        
                        # Получаем комментарии
                        comments = self.vk.wall.getComments(post_id=post['id'], 
                                                          owner_id=post['owner_id'])
                        for comment in comments['items']:
                            if self.analyzer.analyze_message(comment['text']):
                                self._save_lead('vk', str(comment['from_id']), 
                                              comment['text'], 
                                              f"vk.com/wall{post['owner_id']}_{post['id']}?reply={comment['id']}")
                
            except Exception as e:
                logger.error(f"Error in VK monitoring: {e}")
            
            await asyncio.sleep(300)  # Пауза 5 минут между проверками
    
    def _save_lead(self, source, user_id, message, link):
        session = SessionLocal()
        lead = Lead(
            source=source,
            user_id=user_id,
            message=message,
            post_link=link
        )
        session.add(lead)
        session.commit()
        session.close()

class TelegramMonitor:
    def __init__(self, analyzer):
        self.client = TelegramClient('monitor_session', 
                                   CONFIG['TELEGRAM_API_ID'],
                                   CONFIG['TELEGRAM_API_HASH'])
        self.analyzer = analyzer
    
    async def start_monitoring(self):
        await self.client.start()
        
        while True:
            try:
                for channel in CONFIG['TELEGRAM_CHANNELS']:
                    async for message in self.client.iter_messages(channel, 
                                                                 limit=100):
                        # Проверяем возраст сообщения
                        if datetime.now() - message.date > timedelta(days=CONFIG['MAX_POST_AGE_DAYS']):
                            continue
                            
                        if message.text and self.analyzer.analyze_message(message.text):
                            self._save_lead('telegram', 
                                          str(message.from_id), 
                                          message.text,
                                          f"t.me/{channel}/{message.id}")
                            
            except Exception as e:
                logger.error(f"Error in Telegram monitoring: {e}")
                
            await asyncio.sleep(300)
    
    def _save_lead(self, source, user_id, message, link):
        session = SessionLocal()
        lead = Lead(
            source=source,
            user_id=user_id,
            message=message,
            post_link=link
        )
        session.add(lead)
        session.commit()
        session.close()