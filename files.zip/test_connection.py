import os
from dotenv import load_dotenv
import vk_api
from telegram.ext import Application
import asyncio

# Загружаем переменные окружения
load_dotenv()

async def test_connections():
    print("Тестирование подключений...")
    
    # Проверяем VK API
    try:
        vk_session = vk_api.VkApi(token=os.getenv('VK_TOKEN'))
        vk = vk_session.get_api()
        test_request = vk.users.get(user_ids=[1])
        print("✅ Подключение к VK API успешно!")
    except Exception as e:
        print(f"❌ Ошибка подключения к VK API: {e}")

    # Проверяем Telegram Bot API
    try:
        bot = Application.builder().token(os.getenv('TELEGRAM_BOT_TOKEN')).build()
        async with bot:
            me = await bot.bot.get_me()
            print(f"✅ Подключение к Telegram Bot API успешно! Имя бота: {me.first_name}")
    except Exception as e:
        print(f"❌ Ошибка подключения к Telegram Bot API: {e}")

if __name__ == "__main__":
    asyncio.run(test_connections())