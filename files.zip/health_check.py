import asyncio
import psutil
import os
from datetime import datetime
from typing import Dict

class HealthCheck:
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.stats = {}
        
    async def check_system_health(self) -> Dict:
        """Проверка здоровья системы"""
        try:
            # Проверка системных ресурсов
            system_stats = {
                'cpu_percent': psutil.cpu_percent(),
                'memory_percent': psutil.virtual_memory().percent,
                'disk_usage': psutil.disk_usage('/').percent,
                'timestamp': datetime.utcnow().isoformat()
            }
            
            # Проверка состояния файлов
            files_status = {
                'database': os.path.exists('leads.db'),
                'logs': all(os.path.exists(f'logs/{log}') 
                           for log in ['leads_finder.log', 'errors.log', 'stats.log']),
                'models': os.path.exists('models'),
                'training_data': os.path.exists('training_data')
            }
            
            # Обновляем статистику
            self.stats = {
                'system': system_stats,
                'files': files_status,
                'components': await self._check_components()
            }
            
            return self.stats
            
        except Exception as e:
            self.logger.log_error(e, "Error in health check")
            return {}
    
    async def _check_components(self) -> Dict:
        """Проверка состояния компонентов"""
        return {
            'database': await self._check_database(),
            'vk_monitor': await self._check_vk_monitor(),
            'telegram_monitor': await self._check_telegram_monitor(),
            'ai_model': await self._check_ai_model()
        }
    
    async def _check_database(self) -> bool:
        """Проверка работоспособности базы данных"""
        try:
            from database import Database
            db = Database()
            await db.init()
            tables = await db.get_tables()
            return len(tables) > 0
        except Exception:
            return False
    
    async def _check_vk_monitor(self) -> bool:
        """Проверка работоспособности VK монитора"""
        try:
            from vk_monitor import VKMonitor
            monitor = VKMonitor(self.config, None, None, self.logger)
            return bool(monitor.vk_session)
        except Exception:
            return False
    
    async def _check_telegram_monitor(self) -> bool:
        """Проверка работоспособности Telegram монитора"""
        try:
            from telegram_monitor import TelegramMonitor
            monitor = TelegramMonitor(self.config, None, None, self.logger)
            return True
        except Exception:
            return False
    
    async def _check_ai_model(self) -> bool:
        """Проверка работоспособности AI модели"""
        try:
            from local_ai import LocalAI
            ai = LocalAI(self.config)
            return bool(ai.model and ai.tokenizer)
        except Exception:
            return False

    async def start_monitoring(self):
        """Запуск периодического мониторинга"""
        while True:
            try:
                stats = await self.check_system_health()
                self.logger.log_stats({'health_check': stats})
                
                # Проверяем критические показатели
                if stats['system']['cpu_percent'] > 90 or \
                   stats['system']['memory_percent'] > 90 or \
                   stats['system']['disk_usage'] > 90:
                    self.logger.logger.warning("System resources critical!")
                
                # Проверяем компоненты
                for component, status in stats['components'].items():
                    if not status:
                        self.logger.logger.error(f"Component {component} is not functioning!")
                
                await asyncio.sleep(300)  # Проверка каждые 5 минут
                
            except Exception as e:
                self.logger.log_error(e, "Error in health monitoring")
                await asyncio.sleep(60)