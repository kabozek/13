import asyncio
import json
import os
from datetime import datetime
import shutil
from typing import Dict, Optional

class RecoveryManager:
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.backup_dir = 'backups'
        self.last_backup = None
        self.recovery_attempts = {}
        
        # Создаем директорию для бэкапов
        os.makedirs(self.backup_dir, exist_ok=True)

    async def create_backup(self):
        """Создание резервной копии критических данных"""
        try:
            timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
            backup_path = os.path.join(self.backup_dir, f'backup_{timestamp}')
            os.makedirs(backup_path, exist_ok=True)

            # Бэкап базы данных
            if os.path.exists('leads.db'):
                shutil.copy2('leads.db', os.path.join(backup_path, 'leads.db'))

            # Бэкап конфигурации
            config_backup = {
                'timestamp': timestamp,
                'config': self.config,
                'stats': await self._get_current_stats()
            }
            
            with open(os.path.join(backup_path, 'config.json'), 'w') as f:
                json.dump(config_backup, f, indent=2)

            # Бэкап обучающих данных
            if os.path.exists('training_data'):
                shutil.copytree('training_data', 
                               os.path.join(backup_path, 'training_data'),
                               dirs_exist_ok=True)

            self.last_backup = timestamp
            self.logger.logger.info(f"Backup created successfully: {backup_path}")
            
            # Удаляем старые бэкапы (оставляем последние 5)
            await self._cleanup_old_backups()
            
            return backup_path

        except Exception as e:
            self.logger.log_error(e, "Error creating backup")
            return None

    async def restore_from_backup(self, backup_timestamp: Optional[str] = None) -> bool:
        """Восстановление из резервной копии"""
        try:
            if not backup_timestamp:
                # Используем последний бэкап
                backups = sorted([d for d in os.listdir(self.backup_dir) 
                                if d.startswith('backup_')])
                if not backups:
                    raise ValueError("No backups found")
                backup_timestamp = backups[-1].replace('backup_', '')

            backup_path = os.path.join(self.backup_dir, f'backup_{backup_timestamp}')
            
            if not os.path.exists(backup_path):
                raise ValueError(f"Backup {backup_timestamp} not found")

            # Восстанавливаем базу данных
            db_backup = os.path.join(backup_path, 'leads.db')
            if os.path.exists(db_backup):
                shutil.copy2(db_backup, 'leads.db')

            # Восстанавливаем конфигурацию
            with open(os.path.join(backup_path, 'config.json'), 'r') as f:
                config_backup = json.load(f)
                self.config.update(config_backup['config'])

            # Восстанавливаем обучающие данные
            training_backup = os.path.join(backup_path, 'training_data')
            if os.path.exists(training_backup):
                shutil.rmtree('training_data', ignore_errors=True)
                shutil.copytree(training_backup, 'training_data')

            self.logger.logger.info(f"System restored from backup: {backup_timestamp}")
            return True

        except Exception as e:
            self.logger.log_error(e, "Error restoring from backup")
            return False

    async def handle_component_failure(self, component_name: str, error: Exception) -> bool:
        """Обработка сбоя компонента системы"""
        try:
            # Увеличиваем счетчик попыток восстановления
            self.recovery_attempts[component_name] = self.recovery_attempts.get(component_name, 0) + 1
            
            self.logger.logger.warning(
                f"Component failure detected: {component_name}, "
                f"attempt {self.recovery_attempts[component_name]}"
            )

            # Если слишком много попыток, создаем бэкап и пробуем полное восстановление
            if self.recovery_attempts[component_name] >= 3:
                await self.create_backup()
                success = await self.restore_from_backup()
                if success:
                    self.recovery_attempts[component_name] = 0
                    return True
                return False

            # Специфичное восстановление для разных компонентов
            if component_name == 'database':
                return await self._recover_database()
            elif component_name == 'vk_monitor':
                return await self._recover_vk_monitor()
            elif component_name == 'telegram_monitor':
                return await self._recover_telegram_monitor()
            elif component_name == 'ai_model':
                return await self._recover_ai_model()

            return False

        except Exception as e:
            self.logger.log_error(e, f"Error in recovery process for {component_name}")
            return False

    async def _cleanup_old_backups(self):
        """Удаление старых резервных копий"""
        try:
            backups = sorted([d for d in os.listdir(self.backup_dir) 
                            if d.startswith('backup_')])
            
            while len(backups) > 5:
                oldest_backup = backups.pop(0)
                shutil.rmtree(os.path.join(self.backup_dir, oldest_backup))
                self.logger.logger.info(f"Removed old backup: {oldest_backup}")

        except Exception as e:
            self.logger.log_error(e, "Error cleaning up old backups")

    async def _get_current_stats(self) -> Dict:
        """Получение текущей статистики системы"""
        return {
            'timestamp': datetime.utcnow().isoformat(),
            'recovery_attempts': self.recovery_attempts,
            'last_backup': self.last_backup,
            'system_status': {
                'database': os.path.exists('leads.db'),
                'training_data': os.path.exists('training_data'),
                'models': os.path.exists('models')
            }
        }

    async def _recover_database(self) -> bool:
        """Восстановление базы данных"""
        try:
            # Попытка восстановить из последнего бэкапа
            return await self.restore_from_backup()
        except Exception:
            return False

    async def _recover_vk_monitor(self) -> bool:
        """Восстановление VK монитора"""
        try:
            # Сброс сессии и переинициализация
            from vk_monitor import VKMonitor
            monitor = VKMonitor(self.config, None, None, self.logger)
            await monitor.init()
            return True
        except Exception:
            return False

    async def _recover_telegram_monitor(self) -> bool:
        """Восстановление Telegram монитора"""
        try:
            # Пересоздание сессии
            if os.path.exists('*.session'):
                os.remove('*.session')
            from telegram_monitor import TelegramMonitor
            monitor = TelegramMonitor(self.config, None, None, self.logger)
            await monitor.init()
            return True
        except Exception:
            return False

    async def _recover_ai_model(self) -> bool:
        """Восстановление AI модели"""
        try:
            # Перезагрузка модели
            from local_ai import LocalAI
            ai = LocalAI(self.config)
            await ai.init()
            return True
        except Exception:
            return False