import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
import joblib
import os
import logging

class LocalAI:
    def __init__(self, config):
        self.config = config
        self.device = torch.device('cuda' if torch.cuda.is_available() and config['LOCAL_AI']['USE_GPU'] else 'cpu')
        
        # Создаем директорию для моделей, если её нет
        os.makedirs('models', exist_ok=True)
        
        # Загрузка легковесной модели для русского языка
        try:
            self.tokenizer = AutoTokenizer.from_pretrained('DeepPavlov/rubert-base-cased')
            self.model = AutoModelForSequenceClassification.from_pretrained(
                'DeepPavlov/rubert-base-cased',
                num_labels=2  # бинарная классификация
            )
            self.model.to(self.device)
        except Exception as e:
            logging.error(f"Error loading BERT model: {e}")
            raise
        
        # Создаем простой классификатор на основе TF-IDF
        self.vectorizer = TfidfVectorizer(max_features=5000)
        self.classifier = MultinomialNB()
        
        # Загружаем или создаем базу паттернов
        self.load_patterns()
        
    def load_patterns(self):
        """Загрузка или создание базы паттернов"""
        patterns_path = os.path.join('models', 'patterns.joblib')
        try:
            if os.path.exists(patterns_path):
                self.patterns = joblib.load(patterns_path)
            else:
                self.patterns = {
                    'financial': self.config['PATTERNS']['FINANCIAL_DIFFICULTY'],
                    'life_events': self.config['PATTERNS']['LIFE_EVENTS'],
                    'emergency': self.config['PATTERNS']['EMERGENCY']
                }
                joblib.dump(self.patterns, patterns_path)
                logging.info("Created new patterns database")
        except Exception as e:
            logging.error(f"Error handling patterns: {e}")
            raise
    
    async def analyze_text(self, text: str) -> dict:
        """Анализ текста на предмет потенциальной заинтересованности"""
        try:
            # Базовая проверка на спам и нежелательный контент
            if any(pattern in text.lower() for pattern in self.config['NEGATIVE_PATTERNS']):
                return {'relevant': False, 'score': 0, 'category': 'spam'}
            
            # Проверка паттернов
            pattern_matches = self.check_patterns(text)
            if not pattern_matches['matches']:
                return {'relevant': False, 'score': 0, 'category': 'irrelevant'}
            
            # Анализ тональности
            sentiment = await self.get_sentiment(text)
            
            # Определение категории и оценка релевантности
            category = self.categorize_text(text, pattern_matches, sentiment)
            
            return {
                'relevant': category['score'] > self.config['LOCAL_AI']['THRESHOLD'],
                'score': category['score'],
                'category': category['type'],
                'urgency': category['urgency'],
                'patterns_found': pattern_matches['matches']
            }
        except Exception as e:
            logging.error(f"Error analyzing text: {e}")
            return {'relevant': False, 'score': 0, 'category': 'error', 'error': str(e)}
    
    async def get_sentiment(self, text: str) -> float:
        """Анализ тональности текста"""
        try:
            inputs = self.tokenizer(text, return_tensors='pt', truncation=True, max_length=512)
            inputs = {k: v.to(self.device) for k, v in inputs.items()}
            
            with torch.no_grad():
                outputs = self.model(**inputs)
                scores = torch.softmax(outputs.logits, dim=1)
                return scores[0].cpu().numpy()
        except Exception as e:
            logging.error(f"Error in sentiment analysis: {e}")
            return np.array([0.5, 0.5])  # нейтральная оценка в случае ошибки
    
    def check_patterns(self, text: str) -> dict:
        """Проверка текста на наличие паттернов"""
        text = text.lower()
        matches = {
            'financial': [],
            'life_events': [],
            'emergency': []
        }
        
        for category, patterns in self.patterns.items():
            for pattern in patterns:
                if pattern in text:
                    matches[category].append(pattern)
        
        return {
            'matches': any(matches.values()),
            'categories': {k: len(v) for k, v in matches.items()},
            'details': matches
        }
    
    def categorize_text(self, text: str, pattern_matches: dict, sentiment: np.ndarray) -> dict:
        """Категоризация текста и оценка релевантности"""
        # Базовая оценка на основе паттернов
        pattern_score = sum(len(matches) for matches in pattern_matches['details'].values()) / 10
        
        # Оценка срочности
        urgency = len(pattern_matches['details']['emergency']) > 0
        
        # Комбинированная оценка с учетом тональности
        final_score = pattern_score * (0.7 + (0.3 * sentiment[1]))  # sentiment[1] - негативная тональность
        
        return {
            'type': self.get_category_type(pattern_matches),
            'score': min(final_score, 1.0),
            'urgency': urgency
        }
    
    def get_category_type(self, pattern_matches: dict) -> str:
        """Определение основной категории на основе паттернов"""
        categories = pattern_matches['categories']
        if categories['financial'] > categories['life_events']:
            return 'financial_problems'
        elif categories['life_events'] > 0:
            return 'life_situation'
        return 'general'