import vk_api
import logging
from typing import List, Dict, Optional
from datetime import datetime
import json
from config import VK_TOKEN

class VKLeadsFinder:
    def __init__(self, token: str = VK_TOKEN):
        """Инициализация VK API клиента"""
        self.logger = logging.getLogger('VKLeadsFinder')
        self.session = vk_api.VkApi(token=token)
        self.vk = self.session.get_api()
        
    def check_connection(self) -> bool:
        """Проверка подключения к VK API"""
        try:
            self.vk.users.get(user_ids=[1])
            return True
        except Exception as e:
            self.logger.error(f"VK API connection check failed: {e}")
            return False

    async def search_leads_in_group(self, group_id: str, keywords: List[str], 
                                  post_count: int = 100) -> List[Dict]:
        """Поиск лидов в группе по ключевым словам"""
        try:
            # Получаем посты группы
            posts = self.vk.wall.get(owner_id=f"-{group_id}", count=post_count)
            leads = []

            for post in posts['items']:
                text = post.get('text', '').lower()
                if any(keyword.lower() in text for keyword in keywords):
                    lead = {
                        'post_id': post['id'],
                        'text': post['text'],
                        'date': datetime.fromtimestamp(post['date']),
                        'likes': post.get('likes', {}).get('count', 0),
                        'comments': post.get('comments', {}).get('count', 0),
                        'url': f"https://vk.com/wall-{group_id}_{post['id']}"
                    }
                    leads.append(lead)
            
            return leads
        except Exception as e:
            self.logger.error(f"Error searching leads in group {group_id}: {e}")
            return []

    async def get_group_info(self, group_id: str) -> Optional[Dict]:
        """Получение информации о группе"""
        try:
            group = self.vk.groups.getById(group_id=group_id, 
                                         fields=['members_count', 'activity', 
                                                'description', 'status'])[0]
            return {
                'id': group['id'],
                'name': group['name'],
                'members_count': group.get('members_count', 0),
                'description': group.get('description', ''),
                'status': group.get('status', '')
            }
        except Exception as e:
            self.logger.error(f"Error getting group info for {group_id}: {e}")
            return None

    async def analyze_group_activity(self, group_id: str, 
                                   days: int = 30) -> Optional[Dict]:
        """Анализ активности группы"""
        try:
            posts = self.vk.wall.get(owner_id=f"-{group_id}", 
                                   count=100)['items']
            
            total_likes = sum(post.get('likes', {}).get('count', 0) 
                            for post in posts)
            total_comments = sum(post.get('comments', {}).get('count', 0) 
                               for post in posts)
            
            return {
                'posts_count': len(posts),
                'avg_likes': total_likes / len(posts) if posts else 0,
                'avg_comments': total_comments / len(posts) if posts else 0,
                'engagement_rate': (total_likes + total_comments) / len(posts) 
                                 if posts else 0
            }
        except Exception as e:
            self.logger.error(f"Error analyzing group {group_id}: {e}")
            return None

    async def get_members_sample(self, group_id: str, 
                               count: int = 1000) -> List[Dict]:
        """Получение выборки участников группы"""
        try:
            members = self.vk.groups.getMembers(group_id=group_id, 
                                              count=count, 
                                              fields=['city', 'country', 
                                                     'activity'])['items']
            return members
        except Exception as e:
            self.logger.error(f"Error getting members for group {group_id}: {e}")
            return []

    async def search_related_groups(self, group_id: str) -> List[Dict]:
        """Поиск похожих групп"""
        try:
            group = await self.get_group_info(group_id)
            if not group:
                return []
                
            similar = self.vk.groups.search(q=group['name'], 
                                          count=50, 
                                          sort=6)  # sort by size
            
            return [g for g in similar['items'] 
                   if g['id'] != int(group_id)][:10]
        except Exception as e:
            self.logger.error(f"Error finding related groups for {group_id}: {e}")
            return []

def init_vk() -> Optional[VKLeadsFinder]:
    """Инициализация VK API клиента"""
    try:
        vk = VKLeadsFinder()
        if vk.check_connection():
            return vk
    except Exception as e:
        logging.error(f"Failed to initialize VK API: {e}")
    return None