const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.json());
app.use(express.static('public'));

// Endpoint to handle form submission
app.post('/submit', (req, res) => {
    const { name, email } = req.body;
    const contact = { name, email };

    // Save contact to a file (you can replace this with a database)
    fs.appendFile('contacts.json', JSON.stringify(contact) + '\n', (err) => {
        if (err) {
            console.error('Failed to save contact:', err);
            res.status(500).send('Failed to save contact.');
        } else {
            res.status(200).send('Contact submitted successfully!');
        }
    });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});