from enum import Enum
import logging
from typing import Dict, Any, Optional
import traceback
from datetime import datetime

class ErrorType(Enum):
    VK_API = "vk_api_error"
    TELEGRAM_API = "telegram_api_error"
    DATABASE = "database_error"
    AI_MODEL = "ai_model_error"
    NETWORK = "network_error"
    RATE_LIMIT = "rate_limit_error"
    VALIDATION = "validation_error"
    PERMISSION = "permission_error"
    UNKNOWN = "unknown_error"

class ErrorHandler:
    def __init__(self, logger):
        self.logger = logger
        self.error_counts = {}
        self.last_errors = {}
        
    def handle_error(self, 
                    error: Exception, 
                    error_type: ErrorType, 
                    context: Optional[Dict[str, Any]] = None) -> bool:
        """
        Обработка ошибки с контекстом
        Возвращает True, если ошибка обработана успешно
        """
        try:
            # Обновляем статистику ошибок
            self.error_counts[error_type] = self.error_counts.get(error_type, 0) + 1
            self.last_errors[error_type] = datetime.now()
            
            error_data = {
                'type': error_type.value,
                'message': str(error),
                'traceback': traceback.format_exc(),
                'context': context or {},
                'timestamp': datetime.now().isoformat()
            }
            
            # Логируем ошибку
            self.logger.log_error(error_data, error_type.value)
            
            # Специфическая обработка разных типов ошибок
            if error_type == ErrorType.VK_API:
                return self._handle_vk_error(error, context)
            elif error_type == ErrorType.TELEGRAM_API:
                return self._handle_telegram_error(error, context)
            elif error_type == ErrorType.RATE_LIMIT:
                return self._handle_rate_limit(error, context)
            elif error_type == ErrorType.DATABASE:
                return self._handle_database_error(error, context)
            elif error_type == ErrorType.AI_MODEL:
                return self._handle_ai_error(error, context)
            else:
                return self._handle_unknown_error(error, context)
                
        except Exception as e:
            self.logger.log_error(e, "Error in error handler")
            return False
            
    def _handle_vk_error(self, error: Exception, context: Dict) -> bool:
        """Обработка ошибок VK API"""
        if 'error_code' in str(error):
            if '6' in str(error):  # Too many requests
                self.logger.logger.warning("VK API rate limit reached, waiting...")
                return False
            elif '5' in str(error):  # Authorization failed
                self.logger.logger.critical("VK API authorization failed!")
                return False
        return True
        
    def _handle_telegram_error(self, error: Exception, context: Dict) -> bool:
        """Обработка ошибок Telegram API"""
        if 'FloodWait' in str(error):
            self.logger.logger.warning("Telegram API rate limit reached, waiting...")
            return False
        elif 'BlockedUser' in str(error):
            user_id = context.get('user_id')
            self.logger.logger.info(f"User {user_id} blocked the bot")
            return True
        return True
        
    def _handle_rate_limit(self, error: Exception, context: Dict) -> bool:
        """Обработка ошибок превышения лимитов"""
        platform = context.get('platform', 'unknown')
        self.logger.logger.warning(f"Rate limit reached for {platform}, implementing delay")
        return False
        
    def _handle_database_error(self, error: Exception, context: Dict) -> bool:
        """Обработка ошибок базы данных"""
        if 'unique constraint' in str(error).lower():
            self.logger.logger.info("Duplicate entry detected, skipping")
            return True
        elif 'connection' in str(error).lower():
            self.logger.logger.error("Database connection error!")
            return False
        return True
        
    def _handle_ai_error(self, error: Exception, context: Dict) -> bool:
        """Обработка ошибок AI модели"""
        if 'CUDA' in str(error):
            self.logger.logger.warning("GPU error, switching to CPU")
            return False
        elif 'memory' in str(error).lower():
            self.logger.logger.warning("Memory error in AI model, reducing batch size")
            return False
        return True
        
    def _handle_unknown_error(self, error: Exception, context: Dict) -> bool:
        """Обработка неизвестных ошибок"""
        self.logger.logger.error(f"Unknown error: {error}")
        return False
        
    def get_error_stats(self) -> Dict:
        """Получение статистики ошибок"""
        return {
            'error_counts': self.error_counts,
            'last_errors': {k.value: v.isoformat() for k, v in self.last_errors.items()},
            'total_errors': sum(self.error_counts.values())
        }