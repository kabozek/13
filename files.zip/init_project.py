import os
import json
import sys
import logging
from dotenv import load_dotenv
import joblib

# Настройка логирования
logging.basicConfig(level=logging.INFO,
                   format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def create_env_file():
    """Создание .env файла"""
    env_content = """VK_TOKEN=77a594a477a594a477a594a413748e1deb777a577a594a410607b1c810a9b325d772a8b
TELEGRAM_BOT_TOKEN=7285264080:AAGBdYPtewJO3eW-2wozRRB5i5PL0AalViM
TELEGRAM_API_ID=29768896
TELEGRAM_API_HASH=b52e165f6131d8ca4868b2fc960f1cd8
TELEGRAM_BOT_USERNAME=ttspch_bot
ADMIN_USERNAME=kabozek"""

    try:
        with open('.env', 'w') as f:
            f.write(env_content)
        os.chmod('.env', 0o600)
        logger.info("✅ Created .env file")
        return True
    except Exception as e:
        logger.error(f"❌ Failed to create .env file: {str(e)}")
        return False

def create_directories():
    """Создание необходимых директорий и файлов"""
    directories = {
        'logs': ['leads_finder.log', 'errors.log', 'stats.log'],
        'models': ['patterns.joblib'],
        'training_data': ['labeled_data.json']
    }
    
    try:
        for dir_name, files in directories.items():
            if not os.path.exists(dir_name):
                os.makedirs(dir_name)
                logger.info(f"✅ Created directory: {dir_name}")
            
            for file_name in files:
                file_path = os.path.join(dir_name, file_name)
                if not os.path.exists(file_path):
                    if file_name.endswith('.json'):
                        with open(file_path, 'w') as f:
                            json.dump([], f)
                    elif file_name.endswith('.log'):
                        open(file_path, 'a').close()
                    elif file_name.endswith('.joblib'):
                        joblib.dump({}, file_path)
                    logger.info(f"✅ Created file: {file_path}")
        return True
    except Exception as e:
        logger.error(f"❌ Failed to create directories: {str(e)}")
        return False

def verify_env():
    """Проверка переменных окружения"""
    load_dotenv(override=True)
    
    required_vars = [
        'VK_TOKEN',
        'TELEGRAM_BOT_TOKEN',
        'TELEGRAM_API_ID',
        'TELEGRAM_API_HASH',
        'TELEGRAM_BOT_USERNAME',
        'ADMIN_USERNAME'
    ]
    
    missing = []
    for var in required_vars:
        if not os.getenv(var):
            missing.append(var)
    
    if missing:
        logger.error(f"❌ Missing environment variables: {', '.join(missing)}")
        return False
    
    logger.info("✅ Environment variables verified")
    return True

def main():
    logger.info("🚀 Starting project initialization...")
    
    # Создаем .env файл
    if not create_env_file():
        return False
    
    # Проверяем переменные окружения
    if not verify_env():
        return False
    
    # Создаем директории и файлы
    if not create_directories():
        return False
    
    logger.info("✨ Project initialized successfully!")
    logger.info("\nℹ️ Next steps:")
    logger.info("1. Verify .env file contents")
    logger.info("2. Run 'python check_system.py' to verify setup")
    logger.info("3. Run 'python main.py' to start the application")
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)