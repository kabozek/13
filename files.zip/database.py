import aiosqlite
from datetime import datetime
import json
import logging
from typing import Optional, Dict, List

class Database:
    def __init__(self, database_path: str = 'leads.db'):
        self.database_path = database_path
        self.logger = logging.getLogger('Database')
        self._connection = None

    async def connect(self) -> aiosqlite.Connection:
        """Создает подключение к базе данных"""
        if not self._connection:
            self._connection = await aiosqlite.connect(self.database_path)
        return self._connection

    async def init(self) -> None:
        """Инициализация базы данных"""
        async with await self.connect() as conn:
            # Создаем таблицу для лидов
            await conn.execute('''
                CREATE TABLE IF NOT EXISTS leads (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT NOT NULL,
                    platform TEXT NOT NULL,
                    source_group TEXT,
                    message_text TEXT,
                    contact_info TEXT,
                    score REAL,
                    category TEXT,
                    status TEXT,
                    source_type TEXT,
                    source_url TEXT,
                    created_at TEXT,
                    updated_at TEXT
                )
            ''')

            # Создаем таблицу для групп
            await conn.execute('''
                CREATE TABLE IF NOT EXISTS groups (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    platform TEXT NOT NULL,
                    group_id TEXT NOT NULL,
                    name TEXT,
                    members_count INTEGER,
                    activity_score REAL,
                    last_post_date TEXT,
                    is_active BOOLEAN,
                    created_at TEXT,
                    updated_at TEXT
                )
            ''')

            # Создаем таблицу для статистики
            await conn.execute('''
                CREATE TABLE IF NOT EXISTS stats (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    stat_type TEXT NOT NULL,
                    stat_data TEXT NOT NULL,
                    created_at TEXT
                )
            ''')

            await conn.commit()

    async def close(self) -> None:
        """Закрывает соединение с базой данных"""
        if self._connection:
            await self._connection.close()
            self._connection = None

    async def add_lead(self, lead_data: Dict) -> int:
        """Добавляет нового лида в базу"""
        async with await self.connect() as conn:
            cursor = await conn.execute('''
                INSERT INTO leads (
                    user_id, platform, source_group, message_text, 
                    contact_info, score, category, status, 
                    source_type, source_url, created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                lead_data['user_id'],
                lead_data['platform'],
                lead_data.get('source_group'),
                lead_data.get('message_text'),
                lead_data.get('contact_info'),
                lead_data.get('score'),
                lead_data.get('category'),
                lead_data.get('status', 'new'),
                lead_data.get('source_type'),
                lead_data.get('source_url'),
                datetime.utcnow().isoformat(),
                datetime.utcnow().isoformat()
            ))
            await conn.commit()
            return cursor.lastrowid

    async def get_lead(self, lead_id: int) -> Optional[Dict]:
        """Получает лида по ID"""
        async with await self.connect() as conn:
            cursor = await conn.execute('SELECT * FROM leads WHERE id = ?', (lead_id,))
            row = await cursor.fetchone()
            if row:
                return dict(zip([col[0] for col in cursor.description], row))
            return None

    async def update_lead(self, lead_id: int, update_data: Dict) -> bool:
        """Обновляет информацию о лиде"""
        update_data['updated_at'] = datetime.utcnow().isoformat()
        fields = ', '.join([f"{k} = ?" for k in update_data.keys()])
        values = list(update_data.values())
        values.append(lead_id)

        async with await self.connect() as conn:
            cursor = await conn.execute(f'UPDATE leads SET {fields} WHERE id = ?', values)
            await conn.commit()
            return cursor.rowcount > 0

    async def get_leads(self, filters: Dict = None) -> List[Dict]:
        """Получает список лидов с фильтрацией"""
        query = 'SELECT * FROM leads'
        params = []

        if filters:
            conditions = []
            for key, value in filters.items():
                conditions.append(f"{key} = ?")
                params.append(value)
            if conditions:
                query += ' WHERE ' + ' AND '.join(conditions)

        async with await self.connect() as conn:
            cursor = await conn.execute(query, params)
            rows = await cursor.fetchall()
            columns = [col[0] for col in cursor.description]
            return [dict(zip(columns, row)) for row in rows]

    async def add_group(self, group_data: Dict) -> int:
        """Добавляет новую группу в базу"""
        async with await self.connect() as conn:
            cursor = await conn.execute('''
                INSERT INTO groups (
                    platform, group_id, name, members_count,
                    activity_score, last_post_date, is_active,
                    created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                group_data['platform'],
                group_data['group_id'],
                group_data.get('name'),
                group_data.get('members_count'),
                group_data.get('activity_score'),
                group_data.get('last_post_date'),
                group_data.get('is_active', True),
                datetime.utcnow().isoformat(),
                datetime.utcnow().isoformat()
            ))
            await conn.commit()
            return cursor.lastrowid

    async def get_group(self, group_id: str, platform: str) -> Optional[Dict]:
        """Получает группу по ID и платформе"""
        async with await self.connect() as conn:
            cursor = await conn.execute(
                'SELECT * FROM groups WHERE group_id = ? AND platform = ?',
                (group_id, platform)
            )
            row = await cursor.fetchone()
            if row:
                return dict(zip([col[0] for col in cursor.description], row))
            return None

    async def update_group(self, group_id: str, platform: str, update_data: Dict) -> bool:
        """Обновляет информацию о группе"""
        update_data['updated_at'] = datetime.utcnow().isoformat()
        fields = ', '.join([f"{k} = ?" for k in update_data.keys()])
        values = list(update_data.values())
        values.extend([group_id, platform])

        async with await self.connect() as conn:
            cursor = await conn.execute(
                f'UPDATE groups SET {fields} WHERE group_id = ? AND platform = ?',
                values
            )
            await conn.commit()
            return cursor.rowcount > 0

    async def add_stats(self, stat_type: str, stat_data: Dict) -> int:
        """Добавляет новую статистику"""
        async with await self.connect() as conn:
            cursor = await conn.execute('''
                INSERT INTO stats (stat_type, stat_data, created_at)
                VALUES (?, ?, ?)
            ''', (
                stat_type,
                json.dumps(stat_data),
                datetime.utcnow().isoformat()
            ))
            await conn.commit()
            return cursor.lastrowid