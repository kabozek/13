import logging
import json
from datetime import datetime
from typing import Any, Dict

class CustomLogger:
    def __init__(self):
        # Настройка основного логгера
        self.logger = logging.getLogger('LeadsFinder')
        self.logger.setLevel(logging.INFO)
        
        # Создаем форматтер
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
        # Хендлер для файла
        file_handler = logging.FileHandler('logs/leads_finder.log')
        file_handler.setFormatter(formatter)
        
        # Хендлер для консоли
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        
        # Добавляем хендлеры
        self.logger.addHandler(file_handler)
        self.logger.addHandler(console_handler)
        
        # Отдельные логгеры для разных типов данных
        self.error_logger = self._setup_logger('errors.log')
        self.stats_logger = self._setup_logger('stats.log')
    
    def _setup_logger(self, filename: str) -> logging.Logger:
        """Настройка отдельного логгера"""
        logger = logging.getLogger(f'LeadsFinder.{filename}')
        logger.setLevel(logging.INFO)
        
        handler = logging.FileHandler(f'logs/{filename}')
        handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s'))
        
        logger.addHandler(handler)
        return logger
    
    def log_error(self, error: Exception, context: str = "") -> None:
        """Логирование ошибок"""
        error_data = {
            "error": str(error),
            "context": context,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        self.error_logger.error(json.dumps(error_data))
        self.logger.error(f"Error occurred: {json.dumps(error_data)}")
    
    def log_stats(self, stats: Dict[str, Any]) -> None:
        """Логирование статистики"""
        stats_data = {
            "timestamp": datetime.now().isoformat(),
            "data": stats
        }
        
        self.stats_logger.info(json.dumps(stats_data))